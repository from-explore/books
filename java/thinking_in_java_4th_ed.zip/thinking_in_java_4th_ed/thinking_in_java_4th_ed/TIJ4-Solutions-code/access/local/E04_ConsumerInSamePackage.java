//: access/local/E04_ConsumerInSamePackage.java
package access.local;

public class E04_ConsumerInSamePackage {
  public static void main(String[] args) {
    E04_PackagedClass.greeting();
  }
} /* Output:
Hello client programmer!
*///:~
