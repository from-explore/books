//: access/local/E01_PackagedClass.java
/****************** Exercise 1 ****************
 * Create a class in a package. Create an 
 * instance of your class outside of that package.
 ***********************************************/
package access.local;

public class E01_PackagedClass {
} ///:~
