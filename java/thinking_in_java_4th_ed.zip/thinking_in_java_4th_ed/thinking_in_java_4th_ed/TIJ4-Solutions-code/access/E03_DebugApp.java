//: access/E03_DebugApp.java
package access;
import static access.debug.E03_Debug.*;

public class E03_DebugApp {
   public static void main(String[] args) {
      debug("DEBUG VERSION");
   }
} /* Output:
Message: DEBUG VERSION
*///:~
