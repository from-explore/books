//: access/E01_ForeignClass.java
package access;

public class E01_ForeignClass {
  public static void main(String[] args) {
    new access.local.E01_PackagedClass();
  }
} ///:~
