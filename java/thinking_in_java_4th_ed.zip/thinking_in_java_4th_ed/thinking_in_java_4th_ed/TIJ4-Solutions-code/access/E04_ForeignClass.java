//: access/E04_ForeignClass.java
// {CompileTimeError} to see results
package access;

public class E04_ForeignClass {
  public static void main(String[] args) {
    access.local.E04_PackagedClass.greeting();
  }
} ///:~
