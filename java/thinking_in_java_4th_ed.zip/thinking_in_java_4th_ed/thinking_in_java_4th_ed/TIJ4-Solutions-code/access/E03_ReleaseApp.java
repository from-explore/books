//: access/E03_ReleaseApp.java
package access;
import static access.debugoff.E03_Debug.*;

public class E03_ReleaseApp {
   public static void main(String[] args) {
      debug("RELEASE VERSION");
   }
} ///:~
