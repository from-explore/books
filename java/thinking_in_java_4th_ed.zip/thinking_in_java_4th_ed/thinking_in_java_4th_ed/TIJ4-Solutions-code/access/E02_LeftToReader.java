//: access/E02_LeftToReader.java
/****************** Exercise 2 ******************
 * Turn the code fragments in the "Collisions" 
 * section into a program, and  verify that 
 * collisions do in fact occur.
 ***********************************************/
package access;

public class E02_LeftToReader {
  public static void main(String args[]) {
    System.out.println("Exercise left to reader");
  }
} ///:~
