//: access/debugoff/E03_Debug.java
package access.debugoff;

public class E03_Debug {
  public static void debug(String msg) {}
} ///:~
