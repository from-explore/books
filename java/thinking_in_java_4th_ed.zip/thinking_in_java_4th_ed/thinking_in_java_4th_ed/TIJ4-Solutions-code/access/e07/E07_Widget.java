//: access/e07/E07_Widget.java
/****************** Exercise 7 *****************
 * Create the library according to the code
 * fragments describing access and Widget. Create
 * a Widget in a class that is not part of the
 * access package.
 ***********************************************/
package access.e07;
import access.Widget;

public class E07_Widget {
  public static void main(String args[]) {
    new Widget();
  }
} /* Output:
Making a Widget
*///:~
