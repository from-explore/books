//: access/Widget.java
package access;

public class Widget {
  public Widget() {
    System.out.println("Making a Widget");
  }
} ///:~
