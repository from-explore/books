//: polymorphism/cycle3/Bicycle.java
package polymorphism.cycle3;
import polymorphism.cycle.Cycle;

public class Bicycle extends Cycle {
  public void balance() {}
} ///:~
