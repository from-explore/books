//: polymorphism/cycle3/Unicycle.java
package polymorphism.cycle3;
import polymorphism.cycle.Cycle;

public class Unicycle extends Cycle {
  public void balance() {}
} ///:~
