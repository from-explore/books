//: polymorphism/cycle/Unicycle.java
package polymorphism.cycle;

public class Unicycle extends Cycle {
} ///:~
