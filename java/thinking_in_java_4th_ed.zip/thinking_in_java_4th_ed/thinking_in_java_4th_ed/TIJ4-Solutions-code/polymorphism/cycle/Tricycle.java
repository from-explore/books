//: polymorphism/cycle/Tricycle.java
package polymorphism.cycle;

public class Tricycle extends Cycle {
} ///:~
