//: polymorphism/cycle/Cycle.java
package polymorphism.cycle;

public class Cycle {
} ///:~
