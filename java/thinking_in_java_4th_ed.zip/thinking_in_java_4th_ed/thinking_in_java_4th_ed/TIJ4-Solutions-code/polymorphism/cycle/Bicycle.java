//: polymorphism/cycle/Bicycle.java
package polymorphism.cycle;

public class Bicycle extends Cycle {
} ///:~
