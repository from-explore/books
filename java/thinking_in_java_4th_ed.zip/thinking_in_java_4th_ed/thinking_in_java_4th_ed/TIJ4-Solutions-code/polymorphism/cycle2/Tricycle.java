//: polymorphism/cycle2/Tricycle.java
package polymorphism.cycle2;

public class Tricycle extends Cycle {
  public int wheels() { return 3; }
} ///:~
