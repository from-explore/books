//: polymorphism/cycle2/Bicycle.java
package polymorphism.cycle2;

public class Bicycle extends Cycle {
  public int wheels() { return 2; }
} ///:~
