//: polymorphism/cycle2/Cycle.java
package polymorphism.cycle2;

public class Cycle {
  public int wheels() { return 0; }
} ///:~
