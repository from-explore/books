//: polymorphism/cycle2/Unicycle.java
package polymorphism.cycle2;

public class Unicycle extends Cycle {
  public int wheels() { return 1; }
} ///:~
