//: gui/E36_LeftToReader.java
/****************** Exercise 36 ******************
 * Add Frog.class to the manifest file in this
 * section and run jar to create a JAR file containing
 * both Frog and BangBean. Now either download and
 * install the Bean Builder from Sun, or use your
 * own Beans-enabled program builder tool and add
 * the JAR file to your environment so you can test
 * the two Beans.
 ***********************************************/
package gui;

public class E36_LeftToReader {
  public static void main(String args[]) {
    System.out.println("Left to the reader");
  }
} ///:~
