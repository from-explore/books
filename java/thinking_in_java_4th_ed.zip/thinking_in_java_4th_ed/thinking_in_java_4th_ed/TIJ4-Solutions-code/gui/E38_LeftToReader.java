//: gui/E38_LeftToReader.java
/****************** Exercise 38 ******************
 * Build the "simple example of data binding syntax"
 * shown above (see the book).
 ***********************************************/
package gui;

public class E38_LeftToReader {
  public static void main(String args[]) {
    System.out.println("Left to the reader");
  }
} ///:~
