//: gui/E39_LeftToReader.java
/****************** Exercise 39 ******************
 * The code download for this book does not include
 * the MP3s or JPGs shown in SongService.java. Find
 * some MP3s and JPGs, modify SongService.java to
 * include their file names, download the Flex trial
 * and build the application.
 ***********************************************/
package gui;

public class E39_LeftToReader {
  public static void main(String args[]) {
    System.out.println("Left to the reader");
  }
} ///:~
