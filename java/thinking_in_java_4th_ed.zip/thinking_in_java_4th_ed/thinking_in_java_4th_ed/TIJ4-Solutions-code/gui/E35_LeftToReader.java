//: gui/E35_LeftToReader.java
/****************** Exercise 35 ******************
 * Locate and download one or more of the free
 * GUI builder development environments available
 * on the Internet, or use a commercial product if
 * you own one. Discover what is necessary to add
 * BangBean to this environment and to use it.
 ***********************************************/
package gui;

public class E35_LeftToReader {
  public static void main(String args[]) {
    System.out.println("Left to the reader");
  }
} ///:~
