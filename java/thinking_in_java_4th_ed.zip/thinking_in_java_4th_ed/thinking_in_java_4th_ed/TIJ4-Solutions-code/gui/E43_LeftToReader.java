//: gui/E43_LeftToReader.java
/****************** Exercise 43 ******************
 * Choose any one of the Swing examples that wasn't
 * translated in this section, and translate it to
 * SWT.
 ***********************************************/
package gui;

public class E43_LeftToReader {
  public static void main(String args[]) {
    System.out.println("Left to the reader");
  }
} ///:~
