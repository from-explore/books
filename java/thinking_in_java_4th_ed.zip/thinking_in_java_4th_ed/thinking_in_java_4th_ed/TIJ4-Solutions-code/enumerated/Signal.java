//: enumerated/Signal.java
package enumerated;

public enum Signal { GREEN, YELLOW, RED, } ///:~
