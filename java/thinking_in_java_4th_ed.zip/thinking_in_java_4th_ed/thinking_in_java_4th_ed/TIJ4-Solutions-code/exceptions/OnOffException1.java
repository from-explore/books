//: exceptions/OnOffException1.java
package exceptions;
public class OnOffException1 extends Exception {} ///:~
