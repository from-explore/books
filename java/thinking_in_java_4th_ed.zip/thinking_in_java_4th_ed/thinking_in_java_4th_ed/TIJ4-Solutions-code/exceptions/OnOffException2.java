//: exceptions/OnOffException2.java
package exceptions;
public class OnOffException2 extends Exception {} ///:~
