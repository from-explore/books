//: typeinfo/pets1/Gerbil.java
/****************** Exercise 11 *****************
 * Add Gerbil to the typeinfo.pets library and
 * modify all the examples in this chapter to adapt
 * to this new class.
 ***********************************************/
package typeinfo.pets1;

public class Gerbil extends typeinfo.pets.Rodent {
  public Gerbil(String name) { super(name); }
  public Gerbil() {}
} ///:~
