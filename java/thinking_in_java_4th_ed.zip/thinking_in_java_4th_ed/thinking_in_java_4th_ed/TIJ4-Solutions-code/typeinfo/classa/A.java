//: typeinfo/classa/A.java
package typeinfo.classa;

public class A {
  private void a() { System.out.println("A.a()"); }
  protected void b() { System.out.println("A.b()"); }
  void c() { System.out.println("A.c()"); }
} ///:~
