//: innerclasses/exercise6/SimpleInterface.java
package innerclasses.exercise6;

public interface SimpleInterface {
  void f();
} ///:~
