//: interfaces/ownpackage/AnInterface.java
package interfaces.ownpackage;

public interface AnInterface {
  void f();
  void g();
  void h();
} ///:~
