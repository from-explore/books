//: containers/E21_LeftToReader.java
/****************** Exercise 21 *****************
 * Modify SimpleHashMap so that it reports the
 * number of "probes" necessary when collisions
 * occur. That is, how many calls to next() must
 * be made on the Iterators that walk the
 * LinkedLists looking for matches?
 ***********************************************/
package containers;

public class E21_LeftToReader {
  public static void main(String args[]) {
    System.out.println("Exercise left to reader");
  }
} ///:~
