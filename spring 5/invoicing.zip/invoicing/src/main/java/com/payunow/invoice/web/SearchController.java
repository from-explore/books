package com.payunow.invoice.web;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.payunow.invoice.dto.InvoiceSearchApiResponseDTO;
import com.payunow.invoice.request.payload.InvoiceSearchRequest;
import com.payunow.invoice.service.InvoiceSearchService;
import com.payunow.invoice.util.Constants;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/search")
public class SearchController {

	private final static Logger LOGGER = LoggerFactory.getLogger(SearchController.class);

	@Autowired
	private InvoiceSearchService invoiceSearchService;

	@PostMapping("/invoices")
	public Mono<InvoiceSearchApiResponseDTO> searchByInvoiceParams(
			@RequestBody @Valid InvoiceSearchRequest invoiceSearchRequest) {
		final InvoiceSearchApiResponseDTO invociesData = new InvoiceSearchApiResponseDTO();
		try {
			return invoiceSearchService.searchInvoices(invoiceSearchRequest).collectList()
					.flatMap(invoiceSearchResponseDTOList -> {
						LOGGER.info("Successfully fetched {} invoices with request {}",
								invoiceSearchResponseDTOList.size(), invoiceSearchRequest);
						invociesData.setInvoiceSearchResponse(invoiceSearchResponseDTOList);
						invociesData.setErrorCode("" + Constants.SUCCESS);
						invociesData.setErrorMessage(Constants.MSG_SUCCESS);
						return Mono.<InvoiceSearchApiResponseDTO> just(invociesData);
					});
		} catch (Exception e) {
			LOGGER.error("Error while fetching invoice data with {}", invoiceSearchRequest, e);
			invociesData.setErrorCode("" + Constants.FAILURE);
			invociesData.setErrorMessage(Constants.MSG_FAILURE);
			return Mono.<InvoiceSearchApiResponseDTO> just(invociesData);
		}
	}

}