package com.payunow.invoice.validate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.validate.RequestValidator;

@Service
public class SingleInvoiceRequestValidator implements RequestValidator<SinglePaymentInvoice> {

	private final List<RequestValidator<SinglePaymentInvoice>> rules;

	@Autowired
	private SingleInvoiceRequestValidator(List<RequestValidator<SinglePaymentInvoice>> rules) {
		this.rules = rules;
	}

	@Override
	public void validate(SinglePaymentInvoice singleInvoicePaymentRequest) {
		for (RequestValidator<SinglePaymentInvoice> invoiceRequestValidator : rules) {
			invoiceRequestValidator.validate(singleInvoicePaymentRequest);
		}
	}

}
