package com.payunow.invoice.type;

public enum Currency {
	INR, USD, EUR, GBP, LKR, MYR, SGD, CAD, SAR, KWD, AUD, BHD, BDT, HKD, JPY, KES, PHP, MUR, NPR, NZD, OMR, QAR, ZAR, CHF, THB, AED, PLN, CNY, SEK, DKK 
}
