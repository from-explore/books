package com.payunow.invoice.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

public class NotifyThirdParty implements Serializable {

	/**
	 * @author manan.khandelwal
	 */

	private static final long serialVersionUID = 1L;

	private String name;
	private String number;
	private String email;

	public NotifyThirdParty(String name, String number, String email) {
		super();
		this.name = name;
		this.number = number;
		this.email = email;
	}

	public NotifyThirdParty() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public static List<NotifyThirdParty> getThirdPartyNotificationList(List<Document> list) {
		try {
			List<NotifyThirdParty> notifyList = new ArrayList<NotifyThirdParty>();
			for (Document document : list) {
				NotifyThirdParty notify = new NotifyThirdParty(document.getString("name"), document.getString("number"),
						document.getString("email"));
				notifyList.add(notify);
			}
			return notifyList;
		} catch (Exception ex) {
			return null;
		}
	}

	@Override
	public String toString() {
		return "NotifyThirdParty [name=" + name + ", number=" + number + ", email=" + email + "]";
	}

}
