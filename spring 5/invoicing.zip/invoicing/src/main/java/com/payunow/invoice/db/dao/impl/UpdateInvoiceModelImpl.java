package com.payunow.invoice.db.dao.impl;

import java.lang.reflect.Field;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payunow.invoice.db.dao.IUpdateInvoiceModel;
import com.payunow.invoice.db.dao.InvoiceRepository;
import com.payunow.invoice.model.InvoiceModel;

import reactor.core.publisher.Mono;

@Service
public class UpdateInvoiceModelImpl implements IUpdateInvoiceModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateInvoiceModelImpl.class);

	@Autowired
	private InvoiceRepository invoiceRepository;

	@Override
	public Mono<InvoiceModel> update(InvoiceModel invoice, Map<String, Object> params) {
		try {
			LOGGER.info("Updating an invoice {} with params {}", invoice, params);
			for (Map.Entry<String, Object> entry : params.entrySet()) {
				set(invoice, entry.getKey(), entry.getValue());
			}
			return invoiceRepository.save(invoice);
		} catch (Exception e) {
			LOGGER.error("Error while updating an invoice data with invoice number", invoice.getInvoiceNumber(), e);
			throw e;
		}
	}

	private boolean set(Object object, String fieldName, Object fieldValue) {
		Class<?> clazz = object.getClass();
		while (clazz != null) {
			try {
				Field field = clazz.getDeclaredField(fieldName);
				field.setAccessible(true);
				field.set(object, fieldValue);
				return true;
			} catch (NoSuchFieldException e) {
				clazz = clazz.getSuperclass();
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
		}
		return false;
	}

}