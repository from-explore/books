package com.payunow.invoice.dto;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;

public class ErrorBean {

	private static final Logger logger = LoggerFactory.getLogger(ErrorBean.class);

	private String errorCode;
	private String errorMessage;

	public String getErrorCode() {
		return errorCode;
	}

	public ErrorBean() {
	}

	public ErrorBean(String errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	@Override
	public String toString() {
		Gson gson = new Gson();
		try {
			return gson.toJson(this);
		} catch (Exception e) {
			logger.info("Error while convertind invoice to json string", e);
		}
		return null;
	}

}
