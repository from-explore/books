package com.payunow.invoice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.payunow.invoice.dto.EmailNotificationDTO;
import com.payunow.invoice.dto.EmailResponseDTO;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.util.Constants;

import reactor.core.publisher.Mono;

/**
 * Reactive implementation of sending email invoices service.
 * 
 * @author nishant
 *
 */
@Service
public class EmailNotificationService {

	@Value("${payunow.invoice.email.url}")
	private String emailBaseUrl;

	@Value("${payunow.invoice.email.endpoint}")
	private String emailEndPoint;

	private final static Logger LOGGER = LoggerFactory.getLogger(EmailNotificationService.class);

	/**
	 * Send email notification for invoices.
	 * 
	 * @param emailBean
	 * @param invoiceNumber
	 */
	public void triggerEmail(EmailNotificationDTO emailBean, String invoiceNumber) {
		final String url = new StringBuilder(emailBaseUrl).append(emailEndPoint).toString();
		try {
			LOGGER.info("Send email notification for invoiceNumber {} on url {}", invoiceNumber, url);
			WebClient client = WebClient.create();
			Mono<EmailResponseDTO> emailNotificationResponse = client.post().uri(url)
					.contentType(MediaType.APPLICATION_FORM_URLENCODED).syncBody(emailBean).exchange()
					.flatMap(response -> response.bodyToMono(EmailResponseDTO.class));
			emailNotificationResponse.doOnSuccess(emailNotificationRes -> {
				LOGGER.info("Sent email notification for invoiceNumber {} with acknowledgement {}", invoiceNumber,
						emailNotificationRes);
			});
			emailNotificationResponse.doOnError(error -> {
				LOGGER.error("Error while sending email notification for invoiceNumber {}", invoiceNumber, error);
			});
		} catch (Exception e) {
			LOGGER.error("Error while sending email notification for invoiceNumber {}", invoiceNumber, e);
			throw new InvoiceException(Constants.FAILURE, "Email Trigger Failed.");
		}
	}

}