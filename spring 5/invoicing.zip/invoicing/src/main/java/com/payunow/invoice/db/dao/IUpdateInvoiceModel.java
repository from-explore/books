package com.payunow.invoice.db.dao;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.payunow.invoice.model.InvoiceModel;

import reactor.core.publisher.Mono;

/**
 * Reactive implementation of updating invoices service.
 * 
 * @author nishant
 *
 */
@Service
public interface IUpdateInvoiceModel {

	/**
	 * Update an invoice.
	 * 
	 * @param model
	 * 
	 * @return Mono<InvoiceModel>
	 */
	public Mono<InvoiceModel> update(InvoiceModel model, Map<String, Object> param);

}