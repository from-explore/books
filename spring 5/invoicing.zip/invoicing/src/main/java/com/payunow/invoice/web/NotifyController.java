package com.payunow.invoice.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.payunow.invoice.dto.InvoiceTxnFinalResponseDTO;
import com.payunow.invoice.service.NotifyService;

@RestController
@RequestMapping("/notify")
public class NotifyController {

	@Autowired
	NotifyService notifyService;

	@RequestMapping(value = "/invoiceSuccessfulPayment", method = RequestMethod.POST)
	public void updateSuccessfulTransactionInDatabase(@RequestParam(value = "merchantId") String merchantId,
			@RequestParam(value = "invoiceNumber") String invoiceNumber,
			@RequestParam(value = "paymentId") String paymentId) {
		InvoiceTxnFinalResponseDTO successResponseFromPayuMoney = new InvoiceTxnFinalResponseDTO(paymentId,
				invoiceNumber, merchantId);
		notifyService.updateInvoiceTransactionSuccesfulCount(successResponseFromPayuMoney);
	}

}