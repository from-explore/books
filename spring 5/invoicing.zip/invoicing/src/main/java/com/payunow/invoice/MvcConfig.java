package com.payunow.invoice;

import org.springframework.boot.web.reactive.result.view.MustacheViewResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.reactive.config.ResourceHandlerRegistry;
import org.springframework.web.reactive.result.view.ViewResolver;

@Configuration
public class MvcConfig {

	@Bean
	public ViewResolver getViewResolver() {
		MustacheViewResolver mustacheViewResolver = new MustacheViewResolver();
		mustacheViewResolver.setPrefix("/webfronts/html/");
		mustacheViewResolver.setSuffix(".html");
		return mustacheViewResolver;
	}

	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/**").addResourceLocations("/");
	}

	@Bean
	public ReloadableResourceBundleMessageSource messageSource() {
		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
		messageSource.setBasename("classpath:/META-INF/spring/messages");
		messageSource.setDefaultEncoding("UTF-8");
		messageSource.setCacheSeconds(600);
		return messageSource;
	}

}