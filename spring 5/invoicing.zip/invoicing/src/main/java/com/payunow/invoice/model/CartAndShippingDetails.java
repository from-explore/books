package com.payunow.invoice.model;

import java.util.List;

import org.bson.Document;

public class CartAndShippingDetails {

	private List<Cart> cart;

	private Shipping shipping;

	public CartAndShippingDetails(List<Cart> cart, Shipping shipping) {
		super();
		this.cart = cart;
		this.shipping = shipping;
	}

	public CartAndShippingDetails() {

	}

	public Shipping getShipping() {
		return shipping;
	}

	public void setShipping(Shipping shipping) {
		this.shipping = shipping;
	}

	public List<Cart> getCart() {
		return cart;
	}

	public void setCart(List<Cart> cart) {
		this.cart = cart;
	}

	@SuppressWarnings("unchecked")
	public static CartAndShippingDetails getCartAndShippingDetails(Document document) {
		try {
			List<Cart> cartList = Cart.getCartDetails((List<Document>) document.get("cart"));
			Shipping shipping = Shipping.getShippingInfo(document.get("shipping", Document.class));
			CartAndShippingDetails cartAndShippingDetails = new CartAndShippingDetails(cartList, shipping);
			return cartAndShippingDetails;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public String toString() {
		return "CartAndShippingDetails [cart=" + cart + ", shipping=" + shipping + "]";
	}

}
