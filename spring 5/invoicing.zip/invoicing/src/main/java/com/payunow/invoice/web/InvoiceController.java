package com.payunow.invoice.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.payunow.invoice.dto.PaymentInvoiceResponseDTO;
import com.payunow.invoice.request.payload.SingleInvoicePaymentRequest;
import com.payunow.invoice.service.InvoiceService;
import com.payunow.invoice.util.Constants;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/invoices")
public class InvoiceController {

	private final static Logger LOGGER = LoggerFactory.getLogger(InvoiceController.class);

	@Autowired
	private InvoiceService invoiceService;

	@RequestMapping(value = "/singleInvoice", method = RequestMethod.POST)
	public Mono<PaymentInvoiceResponseDTO> createSingleInvoice(
			@RequestBody SingleInvoicePaymentRequest singleInvoiceRequest) {
		final PaymentInvoiceResponseDTO invResp = new PaymentInvoiceResponseDTO();
		try {
			return invoiceService.createSingleInvoicingLink(singleInvoiceRequest).flatMap(shortenedPaymentUrl -> {
				invResp.setSpecialMsg(shortenedPaymentUrl);
				invResp.setResponseCode(Constants.SUCCESS);
				invResp.setResponseMsg(Constants.MSG_SUCCESS);
				invResp.setData(singleInvoiceRequest.getInvoiceNumber());
				LOGGER.info("Successfully returned invoice created response {}", invResp);
				return Mono.<PaymentInvoiceResponseDTO> just(invResp);
			});
		} catch (Exception e) {
			LOGGER.error("Creating invoice with request {}", singleInvoiceRequest, e);
			invResp.setResponseCode(Constants.FAILURE);
			invResp.setResponseMsg(Constants.MSG_FAILURE);
			invResp.setData(singleInvoiceRequest.getInvoiceNumber());
			return Mono.<PaymentInvoiceResponseDTO> just(invResp);
		}
	}

}