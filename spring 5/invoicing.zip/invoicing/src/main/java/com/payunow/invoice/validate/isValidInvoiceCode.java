package com.payunow.invoice.validate;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;

@Component
@Order(4)
public class isValidInvoiceCode implements RequestValidator<SinglePaymentInvoice> {

	@Override
	public void validate(SinglePaymentInvoice t) {
		if (CommonUtil.isNotEmpty(t.getSingleInvoicePaymentRequest().getInvoiceNumber())
				&& !CommonUtil.isAlphaNumeric(t.getSingleInvoicePaymentRequest().getInvoiceNumber())) {
			throw new InvoiceException(Constants.FAILURE, "Invoice Number is Strictly Alpha-numeric");
		}
	}

}
