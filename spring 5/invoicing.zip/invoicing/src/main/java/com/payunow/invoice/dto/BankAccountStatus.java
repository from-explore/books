package com.payunow.invoice.dto;

import java.util.Date;

public class BankAccountStatus {

	private Integer bankAccountStatusId;

	private Integer merchantId;

	private String accountId;

	private Integer pennyStatus;

	private Integer ifscStatus;

	private Integer panStatus;

	private Integer bankVerificationStatus;

	private Boolean panStatusFailed = false;

	private Boolean ifscStatusFailed = false;

	private Boolean pennyStatusFailed = false;

	private Date bankVerificationUpdatedOn;

	private Date pennyDepositClickedOn;

	private Date ifscStatusUpdatedOn;

	private Date panStatusUpdatedOn;

	private Date pennyStatusUpdatedOn;

	private Integer updatedBy = 0;

	private Integer isPreformaProcessed = 0;

	private String utrNumber;

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public Integer getBankAccountStatusId() {
		return bankAccountStatusId;
	}

	public void setBankAccountStatusId(Integer bankAccountStatusId) {
		this.bankAccountStatusId = bankAccountStatusId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public Integer getPennyStatus() {
		return pennyStatus;
	}

	public void setPennyStatus(Integer pennyStatus) {
		this.pennyStatus = pennyStatus;
		this.pennyStatusUpdatedOn = new Date();
	}

	public Integer getIfscStatus() {
		return ifscStatus;
	}

	public void setIfscStatus(Integer ifscStatus) {
		this.ifscStatus = ifscStatus;
		this.ifscStatusUpdatedOn = new Date();
	}

	public Integer getBankVerificationStatus() {
		return bankVerificationStatus;
	}

	public void setBankVerificationStatus(Integer bankVerificationStatus) {
		this.bankVerificationStatus = bankVerificationStatus;
		this.bankVerificationUpdatedOn = new Date();
	}

	public Date getPennyDepositClickedOn() {
		return pennyDepositClickedOn;
	}

	public void setPennyDepositClickedOn() {
		this.pennyDepositClickedOn = new Date();
	}

	public Date getIfscStatusUpdatedOn() {
		return ifscStatusUpdatedOn;
	}

	public Date getPanStatusUpdatedOn() {
		return panStatusUpdatedOn;
	}

	public Date getPennyStatusUpdatedOn() {
		return pennyStatusUpdatedOn;
	}

	public Integer getPanStatus() {
		return panStatus;
	}

	public void setPanStatus(Integer panStatus) {
		this.panStatus = panStatus;
		this.panStatusUpdatedOn = new Date();
	}

	public Date getBankVerificationUpdatedOn() {
		return bankVerificationUpdatedOn;
	}

	public String getUtrNumber() {
		return utrNumber;
	}

	public void setUtrNumber(String utrNumber) {
		this.utrNumber = utrNumber;
	}

	public Boolean getPanStatusFailed() {
		return panStatusFailed;
	}

	public void setPanStatusFailed(Boolean panStatusFailed) {
		this.panStatusFailed = panStatusFailed;
	}

	public Boolean getIfscStatusFailed() {
		return ifscStatusFailed;
	}

	public void setIfscStatusFailed(Boolean ifscStatusFailed) {
		this.ifscStatusFailed = ifscStatusFailed;
	}

	public Boolean getPennyStatusFailed() {
		return pennyStatusFailed;
	}

	public void setPennyStatusFailed(Boolean pennyStatusFailed) {
		this.pennyStatusFailed = pennyStatusFailed;
	}

	public Integer getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Integer getIsPreformaProcessed() {
		return isPreformaProcessed;
	}

	public void setIsPreformaProcessed(Integer isPreformaProcessed) {
		this.isPreformaProcessed = isPreformaProcessed;
	}

}
