package com.payunow.invoice.request.payload;

import java.util.Date;

public class InvoiceSearchRequest {

	private String merchantId;
	private Date from;
	private Date to;
	private String invoiceCode;
	private String invoiceDescription;
	private String status;
	private String amount;

	public InvoiceSearchRequest() {

	}

	public InvoiceSearchRequest(String merchantId, Date from, Date to, String invoiceCode, String invoiceDescription,
			String status, String amount) {
		super();
		this.setMerchantId(merchantId);
		this.from = from;
		this.to = to;
		this.invoiceCode = invoiceCode;
		this.invoiceDescription = invoiceDescription;
		this.status = status;
		this.amount = amount;
	}

	public Date getFrom() {
		return from;
	}

	public void setFrom(Date from) {
		this.from = from;
	}

	public Date getTo() {
		return to;
	}

	public void setTo(Date to) {
		this.to = to;
	}

	public String getInvoiceCode() {
		return invoiceCode;
	}

	public void setInvoiceCode(String invoice_code) {
		this.invoiceCode = invoice_code;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getInvoiceDescription() {
		return invoiceDescription;
	}

	public void setInvoiceDescription(String invoiceDescription) {
		this.invoiceDescription = invoiceDescription;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "InvoiceSearchRequest [from=" + from + ", to=" + to + ", invoiceCode=" + invoiceCode
				+ ", invoiceDescription=" + invoiceDescription + ", status=" + status + ", amount=" + amount + "]";
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

}