package com.payunow.invoice.dto;

public class TDRMerchantConfigurationDaoModel {

	private Integer id;
	private Integer merchantId;
	private Integer tdrMode;
	private String performaCodeNFT;
	private String performaCodeRTGS;
	private Integer tdrStatus;
	private Integer nodalStatus;
	private Integer settlementMode;
	private Integer holdSettlement;
	private Double annualMaintenanceCharges;
	private Double securityDeposit;
	private Double systemIntegrationFees;

	public TDRMerchantConfigurationDaoModel() {
	}

	public TDRMerchantConfigurationDaoModel(Integer id, Integer merchantId, Integer tdrMode, String performaCodeNFT,
			String performaCodeRTGS, Integer tdrStatus, Integer nodalStatus, Integer settlementMode,
			Integer holdSettlement) {
		this.id = id;
		this.merchantId = merchantId;
		this.tdrMode = tdrMode;
		this.performaCodeNFT = performaCodeNFT;
		this.performaCodeRTGS = performaCodeRTGS;
		this.tdrStatus = tdrStatus;
		this.nodalStatus = nodalStatus;
		this.settlementMode = settlementMode;
		this.holdSettlement = holdSettlement;
	}

	public Integer getId() {
		return id;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public Integer getTdrMode() {
		return tdrMode;
	}

	public String getPerformaCodeNFT() {
		return performaCodeNFT;
	}

	public String getPerformaCodeRTGS() {
		return performaCodeRTGS;
	}

	public Integer getTdrStatus() {
		return tdrStatus;
	}

	public Integer getNodalStatus() {
		return nodalStatus;
	}

	public Integer getSettlementMode() {
		return settlementMode;
	}

	public Integer getHoldSettlement() {
		return holdSettlement;
	}

	public Double getAnnualMaintenanceCharges() {
		return annualMaintenanceCharges;
	}

	public void setAnnualMaintenanceCharges(Double annualMaintenanceCharges) {
		this.annualMaintenanceCharges = annualMaintenanceCharges;
	}

	public Double getSecurityDeposit() {
		return securityDeposit;
	}

	public void setSecurityDeposit(Double securityDeposit) {
		this.securityDeposit = securityDeposit;
	}

	public Double getSystemIntegrationFees() {
		return systemIntegrationFees;
	}

	public void setSystemIntegrationFees(Double systemIntegrationFees) {
		this.systemIntegrationFees = systemIntegrationFees;
	}

	public void setNodalStatus(Integer nodalStatus) {
		this.nodalStatus = nodalStatus;
	}

}
