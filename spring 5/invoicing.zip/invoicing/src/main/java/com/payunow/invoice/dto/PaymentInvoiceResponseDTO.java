package com.payunow.invoice.dto;

public class PaymentInvoiceResponseDTO {

	private int responseCode;
	private String responseMsg;
	private String specialMsg;
	private Object data;

	public PaymentInvoiceResponseDTO() {
	}

	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMsg() {
		return responseMsg;
	}

	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getSpecialMsg() {
		return specialMsg;
	}

	public void setSpecialMsg(String specialMsg) {
		this.specialMsg = specialMsg;
	}
}
