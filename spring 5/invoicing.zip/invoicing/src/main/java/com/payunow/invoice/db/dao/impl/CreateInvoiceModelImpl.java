package com.payunow.invoice.db.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payunow.invoice.db.dao.ICreateInvoiceModel;
import com.payunow.invoice.db.dao.InvoiceRepository;
import com.payunow.invoice.model.InvoiceModel;

import reactor.core.publisher.Mono;

@Service
public class CreateInvoiceModelImpl implements ICreateInvoiceModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreateInvoiceModelImpl.class);

	@Autowired
	private InvoiceRepository invoiceRepository;

	@Override
	public Mono<InvoiceModel> create(InvoiceModel invoice) {
		LOGGER.info("Creating an invoice {}", invoice);
		return invoiceRepository.create(invoice);
	}

}