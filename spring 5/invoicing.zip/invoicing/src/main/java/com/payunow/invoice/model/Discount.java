package com.payunow.invoice.model;

import java.io.Serializable;

import org.bson.Document;

public class Discount implements Serializable {

	/**
	 * @author manan.khandelwal
	 */

	private static final long serialVersionUID = 1L;

	private String discountDescription;
	private String discountPercent;
	private String discountAmount;

	public Discount(String discountDescription, String discountPercent, String discountAmount) {
		super();
		this.discountDescription = discountDescription;
		this.discountPercent = discountPercent;
		this.discountAmount = discountAmount;
	}

	public Discount() {
	}

	public String getDiscountDescription() {
		return discountDescription;
	}

	public void setDiscountDescription(String discount_description) {
		this.discountDescription = discount_description;
	}

	public String getDiscountPercent() {
		return discountPercent;
	}

	public void setDiscountPercent(String discount_percent) {
		this.discountPercent = discount_percent;
	}

	public String getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(String discount_amount) {
		this.discountAmount = discount_amount;
	}

	public static Discount getDiscountInfo(Document document) {
		try {
			Discount discount = new Discount(document.getString("discountDescription"),
					document.getString("discountPercent"), document.getString("discountAmount"));
			return discount;
		} catch (Exception e) {
			return null;
		}
	}

}
