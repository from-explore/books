package com.payunow.invoice.dto;

import java.util.Date;

public class MerchantDTO {

	private Integer id;
	private Integer merchantId;
	private String name;
	private String email;
	private String displayName;
	private String phone;
	private String logoJson;
	private String logo;
	private String key;
	private String salt;
	private String secretPassPhrase;
	private Integer applicationStatus;
	private Integer merchantType;
	private AccountDTO account;
	private MerchantBusinessDetailDTO businessDetails;
	private MerchantApplicationStatusDTO appStatus;
	private AddressDTO businessOperationAddress;
	private AddressDTO businessRegisteredAddress;
	private MerchantCategoryDTO category;
	private Integer highRiskCategory;
	private String defaultViewId;
	private Integer holdSettlement;
	private ThirdPartyMerchantAppStatusDTO thirdPartyMerchantAppStatusDTO;
	private Boolean isOfflineMerchantEnabled;
	private Boolean appliedForPos;
	private Date lastTransactionDate;
	private String agentName;
	private String websiteUrl;
	private MerchantStatusDetailsDTO otherDetails;
	private String posType;

	public MerchantDTO() {
	}

	public MerchantDTO(Merchant merchant, MerchantCategoryDTO merchantCategoryDTO, String agentName) {
		merchantId = merchant.getMerchantId();
		name = merchant.getName();
		displayName = merchant.getDisplayName();
		email = merchant.getEmail();
		phone = merchant.getPhone();
		category = merchantCategoryDTO;
		this.agentName = agentName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	public String getSecretPassPhrase() {
		return secretPassPhrase;
	}

	public void setSecretPassPhrase(String secretPassPhrase) {
		this.secretPassPhrase = secretPassPhrase;
	}

	public Integer getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(Integer applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public AccountDTO getAccount() {
		return account;
	}

	public void setAccount(AccountDTO account) {
		this.account = account;
	}

	public MerchantBusinessDetailDTO getMerchantBusinessDetails() {
		return businessDetails;
	}

	public void setMerchantBusinessDetails(MerchantBusinessDetailDTO merchantBusinessDetails) {
		this.businessDetails = merchantBusinessDetails;
	}

	public MerchantApplicationStatusDTO getAppStatus() {
		return appStatus;
	}

	public void setAppStatus(MerchantApplicationStatusDTO appStatus) {
		this.appStatus = appStatus;
	}

	public AddressDTO getBusinessOperationAddress() {
		return businessOperationAddress;
	}

	public void setBusinessOperationAddress(AddressDTO businessOperationAddress) {
		this.businessOperationAddress = businessOperationAddress;
	}

	public AddressDTO getBusinessRegisteredAddress() {
		return businessRegisteredAddress;
	}

	public void setBusinessRegisteredAddress(AddressDTO businessRegisteredAddress) {
		this.businessRegisteredAddress = businessRegisteredAddress;
	}

	public String getLogoJson() {
		return logoJson;
	}

	public void setLogoJson(String logoJson) {
		this.logoJson = logoJson;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public MerchantBusinessDetailDTO getBusinessDetails() {
		return businessDetails;
	}

	public void setBusinessDetails(MerchantBusinessDetailDTO businessDetails) {
		this.businessDetails = businessDetails;
	}

	public MerchantCategoryDTO getCategory() {
		return category;
	}

	public void setCategory(MerchantCategoryDTO category) {
		this.category = category;
	}

	public Integer getHighRiskCategory() {
		return highRiskCategory;
	}

	public void setHighRiskCategory(Integer highRiskCategory) {
		this.highRiskCategory = highRiskCategory;
	}

	public String getDefaultViewId() {
		return defaultViewId;
	}

	public void setDefaultViewId(String defaultViewId) {
		this.defaultViewId = defaultViewId;
	}

	public Boolean getIsOfflineMerchantEnabled() {
		return isOfflineMerchantEnabled;
	}

	public void setIsOfflineMerchantEnabled(Boolean isOfflineMerchantEnabled) {
		this.isOfflineMerchantEnabled = isOfflineMerchantEnabled;
	}

	public String getPosType() {
		return posType;
	}

	public void setPosType(String posType) {
		this.posType = posType;
	}

	public MerchantDTO(String key, String salt) {
		this.key = key;
		this.salt = salt;
	}

	public Integer getHoldSettlement() {
		return holdSettlement;
	}

	public void setHoldSettlement(Integer holdSettlement) {
		this.holdSettlement = holdSettlement;
	}

	public ThirdPartyMerchantAppStatusDTO getThirdPartyMerchantAppStatusDTO() {
		return thirdPartyMerchantAppStatusDTO;
	}

	public void setThirdPartyMerchantAppStatusDTO(ThirdPartyMerchantAppStatusDTO thirdPartyMerchantAppStatusDTO) {
		this.thirdPartyMerchantAppStatusDTO = thirdPartyMerchantAppStatusDTO;
	}

	public Boolean getAppliedForPos() {
		return appliedForPos;
	}

	public void setAppliedForPos(Boolean appliedForPos) {
		this.appliedForPos = appliedForPos;
	}

	public Date getLastTransactionDate() {
		return lastTransactionDate;
	}

	public void setLastTransactionDate(Date lastTransactionDate) {
		this.lastTransactionDate = lastTransactionDate;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public MerchantStatusDetailsDTO getOtherDetails() {
		return otherDetails;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public void setOtherDetails(MerchantStatusDetailsDTO otherDetails) {
		this.otherDetails = otherDetails;
	}

	public Integer getMerchantType() {
		return merchantType;
	}

	public void setMerchantType(Integer merchantType) {
		this.merchantType = merchantType;
	}
}
