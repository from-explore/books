package com.payunow.invoice.validate;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.db.dao.IUpdateInvoiceModel;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.model.InvoiceModel;
import com.payunow.invoice.type.InvoiceLinkStatus;
import com.payunow.invoice.util.Constants;

@Component
@Order(0)
public class isMaxPayReached implements RequestValidator<InvoiceModel> {

	@Autowired
	private IUpdateInvoiceModel updateInvoiceModel;

	@Override
	public void validate(InvoiceModel t) {

		int successfulPayments = t.getSuccesfulPaymentsCount();
		if (t.getMaxPaymentsAllowed() == 0) {
			return;
		}
		if (t.getMaxPaymentsAllowed() <= successfulPayments) {
			Map<String, Object> updateMap = new HashMap<String, Object>();
			updateMap.put("invoiceLinkExpiryStatus", InvoiceLinkStatus.EXPIRED.toString());
			updateInvoiceModel.update(t, updateMap);
			throw new InvoiceException(Constants.FAILURE, "Max payments allowed reached");
		}

	}

}