package com.payunow.invoice.validate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payunow.invoice.model.InvoiceModel;

@Service
public class PaymentRequestValidator implements RequestValidator<InvoiceModel> {

	private final List<RequestValidator<InvoiceModel>> rules;

	@Autowired
	private PaymentRequestValidator(List<RequestValidator<InvoiceModel>> rules) {
		this.rules = rules;
	}

	@Override
	public void validate(InvoiceModel model) {
		for (RequestValidator<InvoiceModel> paymentRequestValidator : rules) {
			paymentRequestValidator.validate(model);
		}
	}

}
