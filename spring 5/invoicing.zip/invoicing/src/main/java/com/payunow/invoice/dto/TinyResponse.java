package com.payunow.invoice.dto;

import java.util.List;
import java.util.Map;

public class TinyResponse {

	private List<Map<String, String>> shortUrl;

	public List<Map<String, String>> getShortUrl() {
		return shortUrl;
	}

	public void setShortUrl(List<Map<String, String>> shortUrl) {
		this.shortUrl = shortUrl;
	}

}
