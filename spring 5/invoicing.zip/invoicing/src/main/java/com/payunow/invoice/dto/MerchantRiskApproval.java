package com.payunow.invoice.dto;

import java.util.Date;

import com.payunow.invoice.util.Constants;

public class MerchantRiskApproval {

	private Integer merchantRiskApprovalId;

	private Integer merchantId;

	private String salesAgentEmail;

	private Integer riskApprovalStatus = Constants.RiskApprovalStatus.NEW.v;

	private Date addedOn;

	private Date updatedOn;

	private String comment;

	public Integer getMerchantRiskApprovalId() {
		return merchantRiskApprovalId;
	}

	public void setMerchantRiskApprovalId(Integer merchantRiskApprovalId) {
		this.merchantRiskApprovalId = merchantRiskApprovalId;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public String getSalesAgentEmail() {
		return salesAgentEmail;
	}

	public void setSalesAgentEmail(String salesAgentEmail) {
		this.salesAgentEmail = salesAgentEmail;
	}

	public Integer getRiskApprovalStatus() {
		return riskApprovalStatus;
	}

	public void setRiskApprovalStatus(Integer riskApprovalStatus) {
		this.riskApprovalStatus = riskApprovalStatus;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

}
