package com.payunow.invoice.dto;

import java.util.Date;

public class Merchant {

	private Integer merchantId;

	private String name;

	private String displayName;

	private String email;

	private String phone;

	private String logo;

	private String logoJson;

	private String vendorKey;

	private String vendorSalt;

	private String secretPassPhrase;

	private Integer applicationStatus;

	private String defaultViewId;

	private Date created;

	private Date updated;

	private Integer updatedBy = 0;

	private Integer merchantType;

	public MerchantApplicationStatus merchantAppStatus;

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getVendorKey() {
		return vendorKey;
	}

	public void setVendorKey(String vendorKey) {
		this.vendorKey = vendorKey;
	}

	public String getVendorSalt() {
		return vendorSalt;
	}

	public void setVendorSalt(String vendorSalt) {
		this.vendorSalt = vendorSalt;
	}

	public String getSecretPassPhrase() {
		return secretPassPhrase;
	}

	public void setSecretPassPhrase(String secretPassPhrase) {
		this.secretPassPhrase = secretPassPhrase;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Integer getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(Integer applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public String getLogoJson() {
		return logoJson;
	}

	public void setLogoJson(String logoJson) {
		this.logoJson = logoJson;
	}

	public MerchantApplicationStatus getMerchantAppStatus() {
		return merchantAppStatus;
	}

	public void setMerchantAppStatus(MerchantApplicationStatus merchantAppStatus) {
		this.merchantAppStatus = merchantAppStatus;
	}

	public String getDefaultViewId() {
		return defaultViewId;
	}

	public void setDefaultViewId(String defaultViewId) {
		this.defaultViewId = defaultViewId;
	}

	public Integer getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Integer getMerchantType() {
		return merchantType;
	}

	public void setMerchantType(Integer merchantType) {
		this.merchantType = merchantType;
	}

	protected void onCreate() {
		updated = created = new Date();
	}

	protected void onUpdate() {
		updated = new Date();
	}
}
