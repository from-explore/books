package com.payunow.invoice.web;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.google.gson.Gson;
import com.payunow.invoice.db.dao.IGetInvoiceModel;
import com.payunow.invoice.db.dao.IUpdateInvoiceModel;
import com.payunow.invoice.dto.CheckoutDTO;
import com.payunow.invoice.dto.PaymentDTO;
import com.payunow.invoice.dto.ResultDTO;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.model.PaymentDetails;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;
import com.payunow.invoice.util.Encryptor;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/invoiceCheckout")
public class PayuCheckoutController {

	@Value("${payunow.invoice.add.payment.url}")
	private String addPaymentUrl;

	@Value("${payunow.invoice.decrypt.paymentId.key}")
	private String key;

	@Autowired
	private IGetInvoiceModel getInvoiceModel;

	@Autowired
	private IUpdateInvoiceModel updateInvoiceModel;

	private final static Logger LOGGER = LoggerFactory.getLogger(PayuCheckoutController.class);

	@RequestMapping(value = "/{merchantId}/{invoiceCode}", method = RequestMethod.GET)
	public void redirectToPayuCheckout(@PathVariable("merchantId") String merchantId,
			@PathVariable("invoiceCode") String invoiceCode, final Model model) {
		LOGGER.info("Process payment request with merchantId {} and invoiceCode {}", merchantId, invoiceCode);
		try {
			getInvoiceModel.getInvoiceModelByInvoiceNumberAndMerchantId(invoiceCode, merchantId)
					.doOnSuccess(invoiceModel -> {
						if (CommonUtil.isNull(invoiceModel)) {
							throw new InvoiceException(Constants.FAILURE, "Invoice does not exist");
						}
						CheckoutDTO dto = new CheckoutDTO();
						dto.setMerchantId(merchantId);
						dto.setMerchantTransactionId(invoiceModel.getInvoiceDescription());
						dto.setPurchaseFrom("payu_invoice");
						dto.setTotalAmount(invoiceModel.getTotalAmount());
						dto.getTxnDetails().put("udf1", invoiceModel.getInvoiceNumber());
						WebClient client = WebClient.create();
						Mono<ResultDTO> addPaymentResponse = client.post().uri(addPaymentUrl)
								.contentType(MediaType.APPLICATION_FORM_URLENCODED).syncBody(dto).exchange()
								.flatMap(response -> response.bodyToMono(ResultDTO.class));
						addPaymentResponse.doOnSuccess(addPaymentRes -> {
							LOGGER.info("Add payment response for merchantId {} and invoiceCode {} is {}", merchantId,
									invoiceCode, addPaymentRes);
							PaymentDTO paymentDto = addPaymentRes.getResult();
							String paymentUrl = new StringBuilder(paymentDto.getPageUrl())
									.append(paymentDto.getPaymentId()).toString();
							LOGGER.info("Payment url {}", paymentUrl);
							Map<String, Object> updateMap = new HashMap<String, Object>();
							Map<String, PaymentDetails> paymentDetail = new HashMap<String, PaymentDetails>();
							PaymentDetails addPaymentDetails = new PaymentDetails("FORWARDED", paymentUrl);
							final Gson gson = new Gson();
							if (CommonUtil.isNull(invoiceModel.getPaymentDetails())) {
								paymentDetail.put(Encryptor.decrypt(paymentDto.getPaymentId(), key), addPaymentDetails);
								updateMap.put("paymentDetails", gson.toJson(paymentDetail));
							} else {
								paymentDetail = invoiceModel.getPaymentDetails();
								paymentDetail.put(Encryptor.decrypt(paymentDto.getPaymentId(), key), addPaymentDetails);
								updateMap.put("paymentDetails", gson.toJson(paymentDetail));
							}
							updateInvoiceModel.update(invoiceModel, updateMap);
							ServerResponse.ok().body(Mono.<String> just("redirect:" + paymentUrl), String.class);
						});
						addPaymentResponse.doOnError(error -> {
							LOGGER.error("Error while add payment request with for invoiceNumber {}", invoiceCode,
									error);
							throw new InvoiceException(Constants.FAILURE, "Add payment request failed");
						});
					});
		} catch (Exception e) {
			LOGGER.error("Exception while rendering checkout page ", e);
			throw new InvoiceException(Constants.FAILURE, "Checkout Rendering Failed.");
		}
	}

}
