package com.payunow.invoice.dto;

public class PaymentStatusResponse {

	private int responseCode;
	private String responseMsg;

	public PaymentStatusResponse() {
	}

	public PaymentStatusResponse(int responseCode, String responseMsg) {
		super();
		this.responseCode = responseCode;
		this.responseMsg = responseMsg;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMsg() {
		return responseMsg;
	}

	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}

}
