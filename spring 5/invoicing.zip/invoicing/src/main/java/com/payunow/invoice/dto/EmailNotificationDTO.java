package com.payunow.invoice.dto;

import java.util.HashMap;

public class EmailNotificationDTO {

	private String templateName;

	private String toMail;

	private String subject;

	private String alias;

	private HashMap<String, String> params;

	private String immediate;

	public EmailNotificationDTO(String templateName, String toMail, String subject, String alias,
			HashMap<String, String> params, String immediate) {
		super();
		this.templateName = templateName;
		this.toMail = toMail;
		this.subject = subject;
		this.alias = alias;
		this.params = params;
		this.immediate = immediate;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getToMail() {
		return toMail;
	}

	public void setToMail(String toMail) {
		this.toMail = toMail;
	}

	public HashMap<String, String> getParams() {
		return params;
	}

	public void setParams(HashMap<String, String> params) {
		this.params = params;
	}

	public String getImmediate() {
		return immediate;
	}

	public void setImmediate(String immediate) {
		this.immediate = immediate;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

}
