package com.payunow.invoice.validate;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;
import com.payunow.invoice.util.Encryptor;

@Component
@Order(3)
public class IsValidSingleInvoiceSignature implements RequestValidator<SinglePaymentInvoice> {

	private final static Logger LOGGER = LoggerFactory.getLogger(IsValidSingleInvoiceSignature.class);

	@Override
	public void validate(SinglePaymentInvoice t) {
		String data = new StringBuilder().append(t.getMerchant().getMerchantId())
				.append(CommonUtil.isNull(t.getSingleInvoicePaymentRequest().getAmount().getDiscount()) ? ""
						: t.getSingleInvoicePaymentRequest().getAmount().getDiscount())
				.append(CommonUtil.isNull(t.getSingleInvoicePaymentRequest().getAmount().getTax()) ? ""
						: t.getSingleInvoicePaymentRequest().getAmount().getTax())
				.append(CommonUtil.isNull(t.getSingleInvoicePaymentRequest().getAmount().getShippingCharge()) ? ""
						: t.getSingleInvoicePaymentRequest().getAmount().getShippingCharge())
				.append(CommonUtil.isNull(t.getSingleInvoicePaymentRequest().getAmount().getSubAmount()) ? ""
						: t.getSingleInvoicePaymentRequest().getAmount().getSubAmount())
				.append(CommonUtil.isNull(t.getSingleInvoicePaymentRequest().getCurrency()) ? ""
						: t.getSingleInvoicePaymentRequest().getCurrency())
				.toString();
		LOGGER.info("Data for Signature is {} ", data);
		String key = StringUtils.rightPad(t.getMerchant().getSalt(), 16);
		key = key.replace(" ", "0");
		LOGGER.info("key for Signature is {} ", key);
		String generatedSignature = Encryptor.encrypt(data, key);
		LOGGER.info("Generated Signature is {} and signature passed in API is {}", generatedSignature,
				t.getSingleInvoicePaymentRequest().getSignature());
		if (!t.getSingleInvoicePaymentRequest().getSignature().equals(generatedSignature)) {
			throw new InvoiceException(Constants.FAILURE, "Invalid signature");
		}
	}

}