package com.payunow.invoice.validate;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;

@Component
@Order(2)
public class IsValidMerchantId implements RequestValidator<SinglePaymentInvoice> {

	@Override
	public void validate(SinglePaymentInvoice t) {
		if (!CommonUtil.isNotEmpty(t.getSingleInvoicePaymentRequest().getMerchantId())) {
			throw new InvoiceException(Constants.FAILURE, "Mandatory parameter missing : merchantId");
		}
		if (CommonUtil.isNull(CommonUtil.safeParseInteger(t.getSingleInvoicePaymentRequest().getMerchantId()))
				|| t.getSingleInvoicePaymentRequest().getMerchantId().length() > 10) {
			throw new InvoiceException(Constants.FAILURE, "Invalid merchantId");
		}
	}
}
