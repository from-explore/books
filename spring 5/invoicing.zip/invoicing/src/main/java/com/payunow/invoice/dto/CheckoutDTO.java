package com.payunow.invoice.dto;

import java.util.ArrayList;
import java.util.HashMap;

public class CheckoutDTO {
	private String merchantId;
	private String totalAmount;
	private String paymentIdentifiers = new ArrayList<>().toString();
	private String merchantTransactionId;
	private String purchaseFrom;
	HashMap<String, String> txnDetails = new HashMap<String, String>();

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getPaymentIdentifiers() {
		return paymentIdentifiers;
	}

	public void setPaymentIdentifiers(String paymentIdentifiers) {
		this.paymentIdentifiers = paymentIdentifiers;
	}

	public String getMerchantTransactionId() {
		return merchantTransactionId;
	}

	public void setMerchantTransactionId(String merchantTransactionId) {
		this.merchantTransactionId = merchantTransactionId;
	}

	public String getPurchaseFrom() {
		return purchaseFrom;
	}

	public void setPurchaseFrom(String purchaseFrom) {
		this.purchaseFrom = purchaseFrom;
	}

	public HashMap<String, String> getTxnDetails() {
		return txnDetails;
	}

	public void setTxnDetails(HashMap<String, String> txnDetails) {
		this.txnDetails = txnDetails;
	}
}