package com.payunow.invoice.web;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Encryptor;

@RestController
@RequestMapping("/invoices")
public class GenerateSignatureController {

	private final static Logger LOGGER = LoggerFactory.getLogger(GenerateSignatureController.class);

	@RequestMapping(value = "/GenerateSignature", method = RequestMethod.POST)
	public String generateSignature(@RequestParam(value = "merchantId") String merchantId,
			@RequestParam(value = "discount") String discount, @RequestParam(value = "tax") String tax,
			@RequestParam(value = "shippingCharge") String shippingCharge,
			@RequestParam(value = "subAmount") String subAmount, @RequestParam(value = "currency") String currency,
			@RequestParam(value = "salt") String salt) {

		String data = new StringBuilder().append(merchantId).append(CommonUtil.isNull(discount) ? "" : discount)
				.append(CommonUtil.isNull(tax) ? "" : tax)
				.append(CommonUtil.isNull(shippingCharge) ? "" : shippingCharge)
				.append(CommonUtil.isNull(subAmount) ? "" : subAmount)
				.append(CommonUtil.isNull(currency) ? "" : currency).toString();
		LOGGER.info("Data for Signature is {} ", data);
		String key = StringUtils.rightPad(salt, 16);
		key = key.replace(" ", "0");
		LOGGER.info("key for Signature is {} ", key);
		String generatedSignature = Encryptor.encrypt(data, key);

		return generatedSignature;

	}

}