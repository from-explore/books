package com.payunow.invoice.dto;

public class ThirdPartyMerchantAppStatusDTO {

	private Boolean showBusinessLineApprovalButton = Boolean.FALSE;
	private String courierTrackingNo;
	private String courierDescription;
	private String agreementFileLocation;
	private Integer documentsStatus;
	private String serviceAgreementDetails;
	private Integer serviceAgreementStatus;
	private String bankVerificationLetterDetails;
	private Integer bankVerificationLetterStatus;
	private String govtIssuedCertificateDetails;
	private Integer govtIssuedCertificateStatus;
	private String addressProofDetails;
	private Integer addressProofStatus;
	private String panCardDetails;
	private Integer panCardStatus;
	private String companyPanCardDetails;
	private Integer companyPanCardStatus;
	private String boardResolutionDetails;
	private Integer boardResolutionStatus;
	private Integer contactDetailsWebsiteCheck;
	private Integer tncWebsiteCheck;
	private Integer privacyPolicyWebsiteCheck;
	private Integer refundPolicyWebsiteCheck;
	private Integer onboardingStatus;
	private Integer redmineTicketId;
	private String redmineTicketMessage;
	private Integer integrationType;

	public Boolean getShowBusinessLineApprovalButton() {
		return showBusinessLineApprovalButton;
	}

	public void setShowBusinessLineApprovalButton(Boolean showBusinessLineApprovalButton) {
		this.showBusinessLineApprovalButton = showBusinessLineApprovalButton;
	}

	public ThirdPartyMerchantAppStatusDTO() {
	}

	public String getCourierTrackingNo() {
		return courierTrackingNo;
	}

	public void setCourierTrackingNo(String courierTrackingNo) {
		this.courierTrackingNo = courierTrackingNo;
	}

	public String getAgreementFileLocation() {
		return agreementFileLocation;
	}

	public void setAgreementFileLocation(String agreementFileLocation) {
		this.agreementFileLocation = agreementFileLocation;
	}

	public Integer getDocumentsStatus() {
		return documentsStatus;
	}

	public void setDocumentsStatus(Integer documentsStatus) {
		this.documentsStatus = documentsStatus;
	}

	public String getServiceAgreementDetails() {
		return serviceAgreementDetails;
	}

	public void setServiceAgreementDetails(String serviceAgreementDetails) {
		this.serviceAgreementDetails = serviceAgreementDetails;
	}

	public Integer getServiceAgreementStatus() {
		return serviceAgreementStatus;
	}

	public void setServiceAgreementStatus(Integer serviceAgreementStatus) {
		this.serviceAgreementStatus = serviceAgreementStatus;
	}

	public String getBankVerificationLetterDetails() {
		return bankVerificationLetterDetails;
	}

	public void setBankVerificationLetterDetails(String bankVerificationLetterDetails) {
		this.bankVerificationLetterDetails = bankVerificationLetterDetails;
	}

	public Integer getBankVerificationLetterStatus() {
		return bankVerificationLetterStatus;
	}

	public void setBankVerificationLetterStatus(Integer bankVerificationLetterStatus) {
		this.bankVerificationLetterStatus = bankVerificationLetterStatus;
	}

	public String getGovtIssuedCertificateDetails() {
		return govtIssuedCertificateDetails;
	}

	public void setGovtIssuedCertificateDetails(String govtIssuedCertificateDetails) {
		this.govtIssuedCertificateDetails = govtIssuedCertificateDetails;
	}

	public Integer getGovtIssuedCertificateStatus() {
		return govtIssuedCertificateStatus;
	}

	public void setGovtIssuedCertificateStatus(Integer govtIssuedCertificateStatus) {
		this.govtIssuedCertificateStatus = govtIssuedCertificateStatus;
	}

	public String getAddressProofDetails() {
		return addressProofDetails;
	}

	public void setAddressProofDetails(String addressProofDetails) {
		this.addressProofDetails = addressProofDetails;
	}

	public Integer getAddressProofStatus() {
		return addressProofStatus;
	}

	public void setAddressProofStatus(Integer addressProofStatus) {
		this.addressProofStatus = addressProofStatus;
	}

	public String getPanCardDetails() {
		return panCardDetails;
	}

	public void setPanCardDetails(String panCardDetails) {
		this.panCardDetails = panCardDetails;
	}

	public Integer getPanCardStatus() {
		return panCardStatus;
	}

	public void setPanCardStatus(Integer panCardStatus) {
		this.panCardStatus = panCardStatus;
	}

	public String getCompanyPanCardDetails() {
		return companyPanCardDetails;
	}

	public void setCompanyPanCardDetails(String companyPanCardDetails) {
		this.companyPanCardDetails = companyPanCardDetails;
	}

	public Integer getCompanyPanCardStatus() {
		return companyPanCardStatus;
	}

	public void setCompanyPanCardStatus(Integer companyPanCardStatus) {
		this.companyPanCardStatus = companyPanCardStatus;
	}

	public Integer getContactDetailsWebsiteCheck() {
		return contactDetailsWebsiteCheck;
	}

	public void setContactDetailsWebsiteCheck(Integer contactDetailsWebsiteCheck) {
		this.contactDetailsWebsiteCheck = contactDetailsWebsiteCheck;
	}

	public Integer getTncWebsiteCheck() {
		return tncWebsiteCheck;
	}

	public void setTncWebsiteCheck(Integer tncWebsiteCheck) {
		this.tncWebsiteCheck = tncWebsiteCheck;
	}

	public Integer getPrivacyPolicyWebsiteCheck() {
		return privacyPolicyWebsiteCheck;
	}

	public void setPrivacyPolicyWebsiteCheck(Integer privacyPolicyWebsiteCheck) {
		this.privacyPolicyWebsiteCheck = privacyPolicyWebsiteCheck;
	}

	public Integer getRefundPolicyWebsiteCheck() {
		return refundPolicyWebsiteCheck;
	}

	public void setRefundPolicyWebsiteCheck(Integer refundPolicyWebsiteCheck) {
		this.refundPolicyWebsiteCheck = refundPolicyWebsiteCheck;
	}

	public Integer getOnboardingStatus() {
		return onboardingStatus;
	}

	public void setOnboardingStatus(Integer onboardingStatus) {
		this.onboardingStatus = onboardingStatus;
	}

	public String getCourierDescription() {
		return courierDescription;
	}

	public void setCourierDescription(String courierDescription) {
		this.courierDescription = courierDescription;
	}

	public Integer getRedmineTicketId() {
		return redmineTicketId;
	}

	public void setRedmineTicketId(Integer redmineTicketId) {
		this.redmineTicketId = redmineTicketId;
	}

	public String getRedmineTicketMessage() {
		return redmineTicketMessage;
	}

	public void setRedmineTicketMessage(String redmineTicketMessage) {
		this.redmineTicketMessage = redmineTicketMessage;
	}

	public String getBoardResolutionDetails() {
		return boardResolutionDetails;
	}

	public void setBoardResolutionDetails(String boardResolutionDetails) {
		this.boardResolutionDetails = boardResolutionDetails;
	}

	public Integer getBoardResolutionStatus() {
		return boardResolutionStatus;
	}

	public void setBoardResolutionStatus(Integer boardResolutionStatus) {
		this.boardResolutionStatus = boardResolutionStatus;
	}

	public Integer getIntegrationType() {
		return integrationType;
	}

	public void setIntegrationType(Integer integrationType) {
		this.integrationType = integrationType;
	}

}
