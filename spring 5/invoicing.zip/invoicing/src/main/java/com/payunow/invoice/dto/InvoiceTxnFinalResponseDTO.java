package com.payunow.invoice.dto;

public class InvoiceTxnFinalResponseDTO {

	private String paymentId;

	private String invoiceNumber;

	private String merchantId;

	public InvoiceTxnFinalResponseDTO(String paymentId, String invoiceNumber, String merchantId) {
		super();
		this.paymentId = paymentId;
		this.invoiceNumber = invoiceNumber;
		this.merchantId = merchantId;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

}
