package com.payunow.invoice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.payunow.invoice.dto.MerchantDTO;
import com.payunow.invoice.dto.MerchantDetailResponseBean;
import com.payunow.invoice.exception.InvoiceException;

import reactor.core.publisher.Mono;

@Service
public class MerchantDetailsFetchService {

	@Value("${payunow.merchant.details.base.url}")
	private String baseUrl;

	@Value("${payunow.merchant.details.fetch.url}")
	private String merchantMappingUrl;

	private final static Logger LOGGER = LoggerFactory.getLogger(MerchantDetailsFetchService.class);

	public MerchantDTO getMerchantDetailsByMerchantId(String merchantId) {
		return getMerchant(baseUrl.concat(merchantMappingUrl), merchantId);
	}

	private MerchantDTO getMerchant(String requestUrl, String merchantId) {
		final String url = new StringBuilder(requestUrl).append("?").append("mId").append("=").append(merchantId)
				.toString();
		try {
			LOGGER.info("Fetching merchant details from url {}", url);
			WebClient client = WebClient.create();
			Mono<MerchantDetailResponseBean> merchantDetails = client.get().uri(url).accept(MediaType.APPLICATION_JSON)
					.exchange().flatMap(response -> response.bodyToMono(MerchantDetailResponseBean.class));
			merchantDetails.doOnSuccess(merchantDetailsRes -> {
				LOGGER.info("Successfully fetched merchant details from url {} with response {}", url,
						merchantDetailsRes);
			});
			merchantDetails.doOnError(error -> {
				LOGGER.error("Error while Fetching merchant details from url {}", url, error);
			});
			return merchantDetails.block().getResult();
		} catch (Exception error) {
			LOGGER.error("Error while Fetching merchant details from url {}", url, error);
			throw new InvoiceException(HttpStatus.UNAUTHORIZED.value(), "Invalid Merchant");
		}
	}

}