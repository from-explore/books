package com.payunow.invoice.dto;

public class MerchantStatusDetailsDTO {

	private Integer merchantId;
	private Integer BusinessDetailsStatus;
	private Integer BankDetailsStatus;
	private Integer NodalStatus;
	private Integer RiskApprovedStatus;
	private Integer BankVerificationStatus;

	public MerchantStatusDetailsDTO() {
	}

	public MerchantStatusDetailsDTO(MerchantApplicationStatus appStatus, MerchantRiskApproval merchantRiskApproval,
			BankAccountStatus bankAccountStatus, TDRMerchantConfigurationDaoModel tDRMerchantConfiguration) {

		if (appStatus != null) {
			BankDetailsStatus = appStatus.getBankDetailsStatus();
			BusinessDetailsStatus = appStatus.getBusinessDetailsStatus();
			merchantId = appStatus.getMerchantId();
		}

		if (merchantRiskApproval != null) {
			RiskApprovedStatus = merchantRiskApproval.getRiskApprovalStatus();
		}

		if (bankAccountStatus != null) {
			BankVerificationStatus = bankAccountStatus.getBankVerificationStatus();
		}

		if (tDRMerchantConfiguration != null) {
			NodalStatus = tDRMerchantConfiguration.getNodalStatus();
		}
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public Integer getBusinessDetailsStatus() {
		return BusinessDetailsStatus;
	}

	public void setBusinessDetailsStatus(Integer BusinessDetailsStatus) {
		this.BusinessDetailsStatus = BusinessDetailsStatus;
	}

	public Integer getBankDetailsStatus() {
		return BankDetailsStatus;
	}

	public void setBankDetailsStatus(Integer BankDetailsStatus) {
		this.BankDetailsStatus = BankDetailsStatus;
	}

	public Integer getNodalStatus() {
		return NodalStatus;
	}

	public void setNodalStatus(Integer NodalStatus) {
		this.NodalStatus = NodalStatus;
	}

	public Integer getRiskApprovedStatus() {
		return RiskApprovedStatus;
	}

	public void setRiskApprovedStatus(Integer RiskApprovedStatus) {
		this.RiskApprovedStatus = RiskApprovedStatus;
	}

	public Integer getBankVerificationStatus() {
		return BankVerificationStatus;
	}

	public void setBankVerificationStatus(Integer BankVerificationStatus) {
		this.BankVerificationStatus = BankVerificationStatus;
	}
}
