package com.payunow.invoice.dto;

public class MerchantCategoryDTO {
	private Integer id;
	private Integer merchantId;
	private String category;
	private String subCategory;
	private String merchantBusinessType;
	private boolean isPOSEnabled;
	private boolean isInternational;
	private boolean isInternal;
	private boolean isPaid;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public String getMerchantBusinessType() {
		return merchantBusinessType;
	}

	public void setMerchantBusinessType(String merchantBusinessType) {
		this.merchantBusinessType = merchantBusinessType;
	}

	public boolean isIsPOSEnabled() {
		return isPOSEnabled;
	}

	public void setIsPOSEnabled(boolean isPOSEnabled) {
		this.isPOSEnabled = isPOSEnabled;
	}

	public boolean isIsInternational() {
		return isInternational;
	}

	public void setIsInternational(boolean isInternational) {
		this.isInternational = isInternational;
	}

	public boolean isIsInternal() {
		return isInternal;
	}

	public void setIsInternal(boolean isInternal) {
		this.isInternal = isInternal;
	}

	public boolean isIsPaid() {
		return isPaid;
	}

	public void setIsPaid(boolean isPaid) {
		this.isPaid = isPaid;
	}

}
