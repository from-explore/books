package com.payunow.invoice.dto;

public class MerchantBusinessDetailDTO {

    private Integer id;
    private Integer merchantId;
    private String companyDesc;
    private String productDesc;
    private String ownerDetails;
    private String logisticPartner;
    private String dateOfEstablishment;
    private String hasWebsite;
    private String agreedToTerms;
    private String filingStatus;
    private AddressDTO businessOperationAddress;
    private AddressDTO businessRegisteredAddress;
    private String landLine;
    private String additionalLandLines;
    private String fatherName;
    private String websiteUrl;
    private String name;
    private String email;
    private String phone;
    private String nameOnPanCard;
    private Boolean isFillingFirstTime = Boolean.FALSE;
    private Integer merchantOnBoardingStatus;
    private Integer isSelfServe = 0;
    private String tinyUrl;
    private String encryptedTestTxnPaymentId;
    private Boolean hasPhysicalStore = null;
    private Boolean hasCustomerInteraction = null;
    private String androidAppLink;
    private String iosAppLink;
    private Integer posQuestionResponse;
        
    public Integer getId() {
        return id;
    }

    public String getCompanyDesc() {
        return companyDesc;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public String getOwnerDetails() {
        return ownerDetails;
    }

    public String getLogisticPartner() {
        return logisticPartner;
    }

    public String getDateOfEstablishment() {
        return dateOfEstablishment;
    }

    public void setDateOfEstablishment(String dateOfEstablishment) {
        this.dateOfEstablishment = dateOfEstablishment;
    }

    public String getHasWebsite() {
        return hasWebsite;
    }

    public void setHasWebsite(String hasWebsite) {
        this.hasWebsite = hasWebsite;
    }

    public String getAgreedToTerms() {
        return agreedToTerms;
    }

    public void setAgreedToTerms(String agreedToTerms) {
        this.agreedToTerms = agreedToTerms;
    }

    public String getFilingStatus() {
        return filingStatus;
    }

    public void setFilingStatus(String filingStatus) {
        this.filingStatus = filingStatus;
    }

    public AddressDTO getBusinessOperationAddress() {
        return businessOperationAddress;
    }

    public void setBusinessOperationAddress(AddressDTO businessOperationAddress) {
        this.businessOperationAddress = businessOperationAddress;
    }

    public AddressDTO getBusinessRegisteredAddress() {
        return businessRegisteredAddress;
    }

    public void setBusinessRegisteredAddress(AddressDTO businessRegisteredAddress) {
        this.businessRegisteredAddress = businessRegisteredAddress;
    }

    public String getLandLine() {
        return landLine;
    }

    public void setLandLine(String landLine) {
        this.landLine = landLine;
    }

    public String getAdditionalLandLines() {
        return additionalLandLines;
    }

    public void setAdditionalLandLines(String additionalLandLines) {
        this.additionalLandLines = additionalLandLines;
    }

    public Integer getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public void setMerchantContacts(Merchant merchant) {
        this.name = merchant.getName();
        this.phone = merchant.getPhone();
        this.email = merchant.getEmail();
    }

    public String getNameOnPanCard() {
        return nameOnPanCard;
    }

    public void setNameOnPanCard(String nameOnPanCard) {
        this.nameOnPanCard = nameOnPanCard;
    }

    public Boolean getIsFillingFirstTime() {
        return isFillingFirstTime;
    }

    public void setIsFillingFirstTime(Boolean isFillingFirstTime) {
        this.isFillingFirstTime = isFillingFirstTime;
    }

    public Integer getMerchantOnBoardingStatus() {
        return merchantOnBoardingStatus;
    }

    public void setMerchantOnBoardingStatus(Integer merchantOnBoardingStatus) {
        this.merchantOnBoardingStatus = merchantOnBoardingStatus;
    }

    public Integer getIsSelfServe() {
        return isSelfServe;
    }

    public void setIsSelfServe(Integer isSelfServe) {
        this.isSelfServe = isSelfServe;
    }

    public String getTinyUrl() {
        return tinyUrl;
    }

    public void setTinyUrl(String tinyUrl) {
        this.tinyUrl = tinyUrl;
    }

    public String getEncryptedTestTxnPaymentId() {
        return encryptedTestTxnPaymentId;
    }

    public void setEncryptedTestTxnPaymentId(String encryptedTestTxnPaymentId) {
        this.encryptedTestTxnPaymentId = encryptedTestTxnPaymentId;
    }

    public Boolean getHasPhysicalStore() {
        return hasPhysicalStore;
    }

    public void setHasPhysicalStore(Boolean hasPhysicalStore) {
        this.hasPhysicalStore = hasPhysicalStore;
    }

    public Boolean getHasCustomerInteraction() {
        return hasCustomerInteraction;
    }

    public void setHasCustomerInteraction(Boolean hasCustomerInteraction) {
        this.hasCustomerInteraction = hasCustomerInteraction;
    }

    public String getIosAppLink() {
        return iosAppLink;
    }

    public void setIosAppLink(String iosAppLink) {
        this.iosAppLink = iosAppLink;
    }

    public String getAndroidAppLink() {
        return androidAppLink;
    }

    public void setAndroidAppLink(String androidAppLink) {
        this.androidAppLink = androidAppLink;
    }

    public Integer getPosQuestionResponse() {
        return posQuestionResponse;
    }

    public void setPosQuestionResponse(Integer posQuestionResponse) {
        this.posQuestionResponse = posQuestionResponse;
    }

    public MerchantBusinessDetailDTO(String filingStatus, String name) {
        this.filingStatus = filingStatus;
        this.name = name;
    }
    
    
    public MerchantBusinessDetailDTO(){}

    }
