package com.payunow.invoice.db.dao.impl;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.payunow.invoice.db.dao.IGetInvoiceModel;
import com.payunow.invoice.db.dao.InvoiceRepository;
import com.payunow.invoice.model.Amount;
import com.payunow.invoice.model.CartAndShippingDetails;
import com.payunow.invoice.model.Channel;
import com.payunow.invoice.model.InvoiceModel;
import com.payunow.invoice.model.NotifyThirdParty;
import com.payunow.invoice.model.PaymentDetails;
import com.payunow.invoice.model.RecurringInvoiceDetail;
import com.payunow.invoice.model.UserDetails;
import com.payunow.invoice.util.CommonUtil;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class GetInvoiceModelImpl implements IGetInvoiceModel {

	private static final Logger LOGGER = LoggerFactory.getLogger(GetInvoiceModelImpl.class);

	@Autowired
	private InvoiceRepository invoiceRepository;

	@Override
	public Mono<InvoiceModel> getInvoiceModelByInvoiceNumber(String invoiceNumber) {
		try {
			LOGGER.info("Fetching document for invoice number {} from DB", invoiceNumber);
			return invoiceRepository.getInvoiceModelByInvoiceNumber(invoiceNumber);
		} catch (Exception e) {
			LOGGER.error("Error while fetching invoice data with invoice number", invoiceNumber, e);
			throw e;
		}
	}

	@SuppressWarnings("unchecked")
	public InvoiceModel getModel(Document document) {
		try {
			InvoiceModel model = new InvoiceModel();
			Gson gson = new Gson();
			model.setInvoiceNumber(document.getString("invoiceNumber"));
			model.setInvoiceDescription(document.getString("invoiceDescription"));
			model.setCurrency(document.getString("currency"));
			model.setMerchantId(document.getString("merchantId"));
			model.setUserDetails(UserDetails.getUserDetails(document.get("userDetails", Document.class)));
			model.setAmount(Amount.getAmount(document.get("amount", Document.class)));
			model.setShortenedUrl(document.getString("shortenedUrl"));
			model.setAddedOn(document.getString("addedOn"));
			model.setExpiryDate(document.getString("expiryDate"));
			model.setMaxPaymentsAllowed(document.getInteger("maxPaymentsAllowed"));
			model.setSuccesfulPaymentsCount(document.getInteger("succesfulPaymentsCount"));
			model.setInvoiceStatus(document.getString("invoiceStatus"));
			model.setInvoiceLinkstatus(document.getString("invoiceLinkstatus"));
			if (CommonUtil.isNotNull(document.get("paymentDetails"))) {
				Type type = new TypeToken<Map<String, PaymentDetails>>() {
				}.getType();
				HashMap<String, PaymentDetails> paymentDetails = gson
						.fromJson(document.get("paymentDetails").toString(), type);
				model.setPaymentDetails(paymentDetails);
			}
			Document custom = document.get("custom_params", Document.class);
			Map<String, String> customData = getDataMap(custom);
			model.setCustomParams(customData);
			model.setCartAndShippingDetails(CartAndShippingDetails
					.getCartAndShippingDetails((Document) document.get("cartAndShippingDetails")));
			model.setChannel(Channel.getChannelDetails(document.get("channel", Document.class)));
			model.setRecurringInvoiceDetail(
					RecurringInvoiceDetail.getReccuringDetails(document.get("recurringInvoiceDetail", Document.class)));
			model.setNotifyThirdPartyDetails(NotifyThirdParty
					.getThirdPartyNotificationList((List<Document>) document.get("notifyThirdPartyDetails")));

			return model;
		} catch (Exception e) {
			LOGGER.error("Error while converting mongo document to invoice model", e);
		}
		return null;
	}

	private static Map<String, String> getDataMap(Document meta) {
		Map<String, String> metaData = null;

		if (meta != null) {
			metaData = new HashMap<String, String>();
			Set<Entry<String, Object>> entrySetMeta = meta.entrySet();
			for (Entry<String, Object> entry : entrySetMeta) {
				metaData.put(entry.getKey(), entry.getValue().toString());
			}
		}
		return metaData;
	}

	@Override
	public Mono<InvoiceModel> getInvoiceModelByInvoiceNumberAndMerchantId(String invoiceNumber, String merchantId) {
		try {
			LOGGER.info("Fetching document for invoice number {} & merchant id {}", invoiceNumber, merchantId);
			return invoiceRepository.getInvoiceModelByInvoiceNumberAndMerchantId(invoiceNumber, merchantId);
		} catch (Exception e) {
			LOGGER.error("Error while fetching invoice data with invoice number", invoiceNumber, e);
			throw e;
		}
	}

	@Override
	public Flux<InvoiceModel> getInvoiceDocsByMultipleParameters(Map<String, Object> params, String fromDate,
			String toDate) {
		try {
			LOGGER.info("Fetching document for invoice with params {} for start date {} & end date {}", params,
					fromDate, toDate);
			return invoiceRepository.getInvoiceDocsByMultipleParameters(params, fromDate, toDate);
		} catch (Exception e) {
			LOGGER.error("Error while fetching invoice data with params {}", params, e);
			throw e;
		}
	}

	@Override
	public Mono<InvoiceModel> getInvoiceModelByInvoiceLink(String link) {
		try {
			LOGGER.info("Fetching document for invoice with link {} from DB", link);
			return invoiceRepository.getInvoiceModelByInvoiceLink(link);
		} catch (Exception e) {
			LOGGER.error("Error while fetching invoice with link {}", link, e);
			throw e;
		}
	}

}