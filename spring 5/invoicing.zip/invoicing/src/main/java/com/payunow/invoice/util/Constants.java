package com.payunow.invoice.util;

/*
 * Copyright (c) 2012 CitrusPay. All Rights Reserved.
 *
 * This software is the proprietary information of CitrusPay.
 * Use is subject to license terms.
 */
public class Constants {

	public static final int DECIMAL_PLACES = 2;

	public static final int FAILURE = 1;
	public static final int SUCCESS = 0;

	public static final String MSG_FAILURE = "FAILURE";
	public static final String MSG_SUCCESS = "SUCCESS";

	public static final String ERROR_MSG = "Something went wrong, please try again later";
	public static final Integer PENNY_VERIFICATION_MAX_ATTEMPTS = 10;
	
	public static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
			+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

	public static final String PHONE_PATTERN = "^[7-9]{1}[0-9]{9}$";

	public static final String NAME_PATTERN = "[a-zA-Z ]*";

	public static final String ZIP_PATTERN = "[0-9]+";

	public enum BusinessDetailsStatus {

		DISAPPROVED(-1), INCOMPLETE(0), COMPLIANCE_APPROVED(2), COMPLETE(4), APPROVED(8);
		public final int v;

		BusinessDetailsStatus(int value) {
			this.v = value;
		}

	};

	public enum MerchantApprovalStatus {

		REJECTED(-1), NOT_APPROVED_YET(0), Aggregator_Approved(2), TOOLS_APPROVED(4), WEBSITE_APPROVED(
				8), HDFC_ICICI_PG_APPROVED(16);
		public final int v;

		MerchantApprovalStatus(int value) {
			this.v = value;
		}

	};

	public enum NodalStatus {

		NOTSTARTED(0), SENT(2), COMPLETE(4), FAILED(-1);
		public final int v;

		NodalStatus(int value) {
			this.v = value;
		}

	};

	public enum RiskApprovalStatus {

		REJECTED(-1), NEW(0), ON_HOLD(2), APPROVED(4);
		public final int v;

		RiskApprovalStatus(int value) {
			this.v = value;
		}

	};

}
