package com.payunow.invoice.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.payunow.invoice.model.Cart;
import com.payunow.invoice.model.Tax;
import com.payunow.invoice.request.payload.SingleInvoicePaymentRequest;

import au.com.bytecode.opencsv.CSVParser;
import au.com.bytecode.opencsv.CSVReader;

public class CommonUtil {

	public static List<String[]> readCSV(InputStream inputStream) throws IOException {

		Reader reader = new InputStreamReader(inputStream);
		CSVReader csvReader = new CSVReader(reader, CSVParser.DEFAULT_SEPARATOR, CSVParser.DEFAULT_QUOTE_CHARACTER, 0);
		List<String[]> list = csvReader.readAll();
		csvReader.close();
		return list;
	}

	public static boolean isNotNull(Object object) {
		return (object != null) ? Boolean.TRUE : Boolean.FALSE;
	}

	public static boolean isNull(Object object) {
		return (object == null) ? Boolean.TRUE : Boolean.FALSE;
	}

	public static <T> boolean isNotEmpty(List<T> objList) {
		return (isNotNull(objList) && (objList.size() > 0));
	}

	public static <T> boolean isNotEmpty(Set<T> objList) {
		return (isNotNull(objList) && (objList.size() > 0));
	}

	public static <T> boolean isEmpty(List<T> objList) {
		return (isNull(objList) || (objList.size() == 0));
	}

	public static boolean isEmpty(String str) {
		return (str == null || str.trim().isEmpty());
	}

	public static boolean isNotEmpty(String str) {
		return !isEmpty(str);
	}

	public static String handleNull(String str) {
		if (str == null) {
			str = "";
		}
		return str;
	}

	public static String formatTwoDecimalPlaces(double value) {
		return new DecimalFormat("#0.00").format(value);
	}

	public static Double safeParseDouble(String value) {
		try {
			return Double.parseDouble(value);
		} catch (Exception e) {
			return null;
		}
	}

	public static Integer safeParseInteger(String value) {
		try {
			return Integer.parseInt(value);
		} catch (Exception e) {
			return null;
		}
	}

	public static boolean isAlphaNumeric(String s) {
		String pattern = "^[a-zA-Z0-9]*$";
		return s.matches(pattern);
	}

	public static SingleInvoicePaymentRequest SanitizeSingleInvoiceRequest(SingleInvoicePaymentRequest piRequest) {
		if (CommonUtil.isNotNull(piRequest.getAmount())) {
			piRequest.getAmount().setDiscount(StringUtils.trim(piRequest.getAmount().getDiscount()));
			piRequest.getAmount().setShippingCharge(StringUtils.trim(piRequest.getAmount().getShippingCharge()));
			piRequest.getAmount().setTax(StringUtils.trim(piRequest.getAmount().getTax()));
			piRequest.getAmount().setSubAmount(StringUtils.trim(piRequest.getAmount().getSubAmount()));
		}
		if (CommonUtil.isNotNull(piRequest.getCartAndShippingDetails())) {
			if (CommonUtil.isNotNull(piRequest.getCartAndShippingDetails().getCart())) {
				List<Cart> cart = piRequest.getCartAndShippingDetails().getCart();
				for (Cart cartObject : cart) {
					cartObject.setItemId(StringUtils.trim(cartObject.getItemId()));
					cartObject.setItemDescription(StringUtils.trim(cartObject.getItemDescription()));
					cartObject.setUnitPrice(StringUtils.trim(cartObject.getUnitPrice()));
					cartObject.setItemAmount(StringUtils.trim(cartObject.getItemAmount()));
					cartObject.setHeight(StringUtils.trim(cartObject.getHeight()));
					cartObject.setLength(StringUtils.trim(cartObject.getLength()));
					cartObject.setWidth(StringUtils.trim(cartObject.getWidth()));
					if (CommonUtil.isNotNull(cartObject.getTax())) {
						List<Tax> tax = cartObject.getTax();
						for (Tax taxObject : tax) {
							taxObject.setTaxAmount(StringUtils.trim(taxObject.getTaxAmount()));
							taxObject.setTaxDescription(StringUtils.trim(taxObject.getTaxDescription()));
							taxObject.setTaxPercent(StringUtils.trim(taxObject.getTaxPercent()));
						}
					}
					if (CommonUtil.isNotNull(cartObject.getDiscount())) {
						cartObject.getDiscount()
								.setDiscountAmount(StringUtils.trim(cartObject.getDiscount().getDiscountAmount()));
						cartObject.getDiscount().setDiscountDescription(
								StringUtils.trim(cartObject.getDiscount().getDiscountDescription()));
						cartObject.getDiscount()
								.setDiscountPercent(StringUtils.trim(cartObject.getDiscount().getDiscountPercent()));
					}
				}
			}
			if (CommonUtil.isNotNull(piRequest.getCartAndShippingDetails().getShipping())) {
				if (CommonUtil.isNotNull(piRequest.getCartAndShippingDetails().getShipping().getShippingAddress())) {
					piRequest.getCartAndShippingDetails().getShipping().getShippingAddress()
							.setAddressCity(StringUtils.trim(piRequest.getCartAndShippingDetails().getShipping()
									.getShippingAddress().getAddressCity()));
					piRequest.getCartAndShippingDetails().getShipping().getShippingAddress()
							.setAddressCountry(StringUtils.trim(piRequest.getCartAndShippingDetails().getShipping()
									.getShippingAddress().getAddressCountry()));
					piRequest.getCartAndShippingDetails().getShipping().getShippingAddress()
							.setAddressState(StringUtils.trim(piRequest.getCartAndShippingDetails().getShipping()
									.getShippingAddress().getAddressState()));
					piRequest.getCartAndShippingDetails().getShipping().getShippingAddress()
							.setAddressStreet1(StringUtils.trim(piRequest.getCartAndShippingDetails().getShipping()
									.getShippingAddress().getAddressStreet1()));
					piRequest.getCartAndShippingDetails().getShipping().getShippingAddress()
							.setAddressStreet2(StringUtils.trim(piRequest.getCartAndShippingDetails().getShipping()
									.getShippingAddress().getAddressStreet2()));
					piRequest.getCartAndShippingDetails().getShipping().getShippingAddress()
							.setAddressZip(StringUtils.trim(piRequest.getCartAndShippingDetails().getShipping()
									.getShippingAddress().getAddressZip()));
				}
			}
		}
		piRequest.setCurrency(StringUtils.trim(piRequest.getCurrency()));
		if (CommonUtil.isNotNull(piRequest.getCustomParams())) {
			Map<String, String> customParams = piRequest.getCustomParams();
			for (Entry<String, String> entry : customParams.entrySet()) {
				customParams.put(entry.getKey(), StringUtils.trim(entry.getValue()));
			}
		}
		piRequest.setInvoiceDescription(StringUtils.trim(piRequest.getInvoiceDescription()));
		piRequest.setInvoiceStatus(StringUtils.trim(piRequest.getInvoiceStatus()));
		piRequest.setInvoiceNumber(StringUtils.trim(piRequest.getInvoiceNumber()));
		piRequest.setMerchantId(StringUtils.trim(piRequest.getMerchantId()));
		piRequest.setSignature(StringUtils.trim(piRequest.getSignature()));
		if (CommonUtil.isNotNull(piRequest.getUserDetails())) {
			piRequest.getUserDetails()
					.setAlternate_number(StringUtils.trim(piRequest.getUserDetails().getAlternate_number()));
			piRequest.getUserDetails().setEmail(StringUtils.trim(piRequest.getUserDetails().getEmail()));
			piRequest.getUserDetails().setName(StringUtils.trim(piRequest.getUserDetails().getName()));
			piRequest.getUserDetails().setPhone_number(StringUtils.trim(piRequest.getUserDetails().getPhone_number()));
			if (CommonUtil.isNotNull(piRequest.getUserDetails().getAddress())) {

				piRequest.getUserDetails().getAddress()
						.setAddressCity(StringUtils.trim(piRequest.getUserDetails().getAddress().getAddressCity()));
				piRequest.getUserDetails().getAddress().setAddressCountry(
						StringUtils.trim(piRequest.getUserDetails().getAddress().getAddressCountry()));
				piRequest.getUserDetails().getAddress()
						.setAddressState(StringUtils.trim(piRequest.getUserDetails().getAddress().getAddressState()));
				piRequest.getUserDetails().getAddress().setAddressStreet1(
						StringUtils.trim(piRequest.getUserDetails().getAddress().getAddressStreet1()));
				piRequest.getUserDetails().getAddress().setAddressStreet2(
						StringUtils.trim(piRequest.getUserDetails().getAddress().getAddressStreet2()));
				piRequest.getUserDetails().getAddress()
						.setAddressZip(StringUtils.trim(piRequest.getUserDetails().getAddress().getAddressZip()));

			}
		}
		return piRequest;
	}

	public static Object trimRootLevelStringFields(Object bean) {
		if (bean == null) {
			return bean;
		}

		Field[] fields = bean.getClass().getDeclaredFields();
		if (fields == null) {
			return bean;
		}

		for (Field f : fields) {
			if (f.getType().isPrimitive()) {
				continue;
			}

			if (f.getType().equals(String.class)) {
				try {
					f.setAccessible(true);
					String value = (String) f.get(bean);
					f.set(bean, StringUtils.trimToNull(value));
				} catch (IllegalAccessException e) {
				}

			}
		}
		return bean;
	}

}