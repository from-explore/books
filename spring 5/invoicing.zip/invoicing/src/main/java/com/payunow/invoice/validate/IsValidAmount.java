package com.payunow.invoice.validate;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.model.Amount;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;

@Component
@Order(0)
public class IsValidAmount implements RequestValidator<SinglePaymentInvoice> {

	@Override
	public void validate(SinglePaymentInvoice t) {
		Amount amount = t.getSingleInvoicePaymentRequest().getAmount();
		if (CommonUtil.isNull(amount) || CommonUtil.isNull(amount.getSubAmount())) {
			throw new InvoiceException(Constants.FAILURE, "Mandatory parameter missing : Amount");
		}
		if (CommonUtil.isNull(CommonUtil.safeParseDouble(amount.getSubAmount()))) {
			throw new InvoiceException(Constants.FAILURE, "Invalid Amount");
		}
		if (CommonUtil.isNotEmpty(amount.getDiscount())
				&& CommonUtil.isNull(CommonUtil.safeParseDouble(amount.getDiscount()))) {
			throw new InvoiceException(Constants.FAILURE, "Invalid Discount");
		}
		if (CommonUtil.isNotEmpty(amount.getShippingCharge())
				&& CommonUtil.isNull(CommonUtil.safeParseDouble(amount.getShippingCharge()))) {
			throw new InvoiceException(Constants.FAILURE, "Invalid Shipping Charge");
		}
		if (CommonUtil.isNotEmpty(amount.getTax()) && CommonUtil.isNull(CommonUtil.safeParseDouble(amount.getTax()))) {
			throw new InvoiceException(Constants.FAILURE, "Invalid Tax");
		}

	}

}