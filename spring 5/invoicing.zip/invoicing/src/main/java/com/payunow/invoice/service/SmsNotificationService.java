package com.payunow.invoice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.payunow.invoice.dto.SmsNotificationDTO;
import com.payunow.invoice.dto.SmsResponseDTO;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.util.Constants;

import reactor.core.publisher.Mono;

@Service
public class SmsNotificationService {

	@Value("${payunow.invoice.sms.url}")
	private String smsBaseUrl;

	@Value("${payunow.invoice.sms.endpoint}")
	private String smsEndPoint;

	private final static Logger LOGGER = LoggerFactory.getLogger(SmsNotificationService.class);

	public void triggerSms(SmsNotificationDTO smsBean, String invoiceNumber) {
		final String url = new StringBuilder(smsBaseUrl).append(smsEndPoint).toString();
		try {
			LOGGER.info("Send sms notification for invoiceNumber {} on url {}", invoiceNumber, url);
			WebClient client = WebClient.create();
			Mono<SmsResponseDTO> smsNotificationResponse = client.post().uri(url)
					.contentType(MediaType.APPLICATION_FORM_URLENCODED).syncBody(smsBean).exchange()
					.flatMap(response -> response.bodyToMono(SmsResponseDTO.class));
			smsNotificationResponse.doOnSuccess(smsNotificationRes -> {
				LOGGER.info("Sent sms notification for invoiceNumber {} with acknowledgement {}", invoiceNumber,
						smsNotificationRes);
			});
			smsNotificationResponse.doOnError(error -> {
				LOGGER.error("Error while sending sms notification for invoiceNumber {}", invoiceNumber, error);
			});
		} catch (Exception e) {
			LOGGER.error("Error while sending sms notification for invoiceNumber {}", invoiceNumber, e);
			throw new InvoiceException(Constants.FAILURE, "SMS Trigger Failed.");
		}
	}

}