package com.payunow.invoice.util;

import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.payunow.invoice.dto.EmailNotificationDTO;
import com.payunow.invoice.dto.SmsNotificationDTO;
import com.payunow.invoice.request.payload.SingleInvoicePaymentRequest;
import com.payunow.invoice.service.EmailNotificationService;
import com.payunow.invoice.service.InvoiceService;
import com.payunow.invoice.service.SmsNotificationService;

@Service
public class MessagingUtil {

	@Value("${payunow.invoice.email.templateName}")
	private String emailTemplateName;

	@Value("${payunow.invoice.sms.templateName}")
	private String smsTemplateName;

	@Value("${payunow.invoice.email.subject}")
	private String subject;

	@Autowired
	private EmailNotificationService emailNotificationService;

	@Autowired
	private SmsNotificationService smsNotificationService;

	private final static Logger LOGGER = LoggerFactory.getLogger(InvoiceService.class);

	public void pushPaymentLinksViaChannels(SingleInvoicePaymentRequest singleInvoicePaymentRequest, String shortUrl,
			String merchantName, String totalAmount) {
		if (CommonUtil.isNull(singleInvoicePaymentRequest.getChannel()))
			return;
		if (CommonUtil.isNotNull(singleInvoicePaymentRequest.getChannel().getViaEmail())
				&& singleInvoicePaymentRequest.getChannel().getViaEmail()) {
			HashMap<String, String> params = new HashMap<>();
			params.put("transactionId", singleInvoicePaymentRequest.getInvoiceNumber());
			params.put("date",
					CommonUtil.isNull(singleInvoicePaymentRequest.getAddedOn()) ? DateUtil.getDateString(new Date())
							: DateUtil.getDateString(singleInvoicePaymentRequest.getAddedOn()));
			params.put("paymentDescription", singleInvoicePaymentRequest.getInvoiceDescription());
			params.put("amount", totalAmount);
			params.put("amount", totalAmount);
			params.put("url", shortUrl);
			params.put("url", shortUrl);
			params.put("merchantName", merchantName);
			String alias = null;
			subject = subject.replace("<Merchant Name>", merchantName);
			EmailNotificationDTO emailBean = new EmailNotificationDTO(emailTemplateName,
					singleInvoicePaymentRequest.getUserDetails().getEmail(), subject, alias, params, "1");
			LOGGER.info("Triggering Invoice Link Email For The Request with Invoice Number {}",
					singleInvoicePaymentRequest.getInvoiceNumber());
			emailNotificationService.triggerEmail(emailBean, singleInvoicePaymentRequest.getInvoiceNumber());
		}
		if (CommonUtil.isNotNull(singleInvoicePaymentRequest.getChannel().getViaSms())
				&& singleInvoicePaymentRequest.getChannel().getViaSms()) {
			HashMap<String, String> params = new HashMap<>();
			params.put("amount", totalAmount);
			params.put("paymentDescription", singleInvoicePaymentRequest.getInvoiceDescription());
			params.put("merchantName", merchantName);
			params.put("url", shortUrl);
			params.put("contactEmail", "care@payumoney.com");
			SmsNotificationDTO smsBean = new SmsNotificationDTO(smsTemplateName,
					singleInvoicePaymentRequest.getUserDetails().getPhone_number(), "", "", "OTP", "payuinvoice",
					params, "1");
			LOGGER.info("Triggering Invoice Link SMS For The Request with Invoice Number {}",
					singleInvoicePaymentRequest.getInvoiceNumber());
			smsNotificationService.triggerSms(smsBean, singleInvoicePaymentRequest.getInvoiceNumber());
		}
	}

}