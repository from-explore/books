package com.payunow.invoice.dto;

public class SmsResponseDTO {

	private String httpresponseCode;

	private String guid;

	private String message;

	private String phone;

	private String responseCode;

	private String status;

	private String deliveryTime;

	public String getHttpresponseCode() {
		return httpresponseCode;
	}

	public void setHttpresponseCode(String httpresponseCode) {
		this.httpresponseCode = httpresponseCode;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getDeliveryTime() {
		return deliveryTime;
	}

	public void setDeliveryTime(String deliveryTime) {
		this.deliveryTime = deliveryTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
