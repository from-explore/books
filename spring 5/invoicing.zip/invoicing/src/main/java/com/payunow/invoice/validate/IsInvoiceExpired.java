package com.payunow.invoice.validate;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.db.dao.IUpdateInvoiceModel;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.model.InvoiceModel;
import com.payunow.invoice.type.InvoiceLinkStatus;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;
import com.payunow.invoice.util.DateUtil;

@Component
@Order(1)
public class IsInvoiceExpired implements RequestValidator<InvoiceModel> {

	@Autowired
	private IUpdateInvoiceModel updateInvoiceModel;

	@Override
	public void validate(InvoiceModel t) {
		if (InvoiceLinkStatus.EXPIRED.toString().equalsIgnoreCase(t.getInvoiceStatus())) {
			throw new InvoiceException(Constants.FAILURE, "Invoice has already expired");
		}
		Date expiryDate = DateUtil.getDate(t.getExpiryDate());
		Date today = new Date();
		if (CommonUtil.isNotNull(expiryDate) && expiryDate.compareTo(today) < 1) {
			Map<String, Object> updateMap = new HashMap<String, Object>();
			updateMap.put("invoiceLinkExpiryStatus", InvoiceLinkStatus.EXPIRED.toString());
			updateInvoiceModel.update(t, updateMap);
			throw new InvoiceException(Constants.FAILURE, "Invoice has already expired");
		}
	}

}
