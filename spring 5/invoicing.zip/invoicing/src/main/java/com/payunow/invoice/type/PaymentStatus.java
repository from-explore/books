package com.payunow.invoice.type;

public enum PaymentStatus {

	SUCCESS("0"), FAILURE("1"), INITIATED("2");

	String value;

	PaymentStatus(String value) {
		this.value = value;
	}

	public String value() {
		return this.value;
	}

}
