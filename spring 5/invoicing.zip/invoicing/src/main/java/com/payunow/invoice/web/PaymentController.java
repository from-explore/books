package com.payunow.invoice.web;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.payunow.invoice.db.dao.IGetInvoiceModel;
import com.payunow.invoice.db.dao.IUpdateInvoiceModel;
import com.payunow.invoice.dto.MerchantDTO;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.service.InvoiceService;
import com.payunow.invoice.service.MerchantDetailsFetchService;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;
import com.payunow.invoice.validate.PaymentRequestValidator;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/invoice")
public class PaymentController {

	@Autowired
	private IGetInvoiceModel getInvoiceModel;

	@Autowired
	private IUpdateInvoiceModel updateInvoiceModel;

	@Autowired
	private PaymentRequestValidator payRequestValidator;

	@Autowired
	private MerchantDetailsFetchService merchantDetailsFetchService;

	@Value("${payunow.invoice.add.payment.api.url}")
	private String addPaymentApiUrl;

	private final static Logger LOGGER = LoggerFactory.getLogger(InvoiceService.class);

	@RequestMapping(value = "/{merchantId}/{invoiceCode}", method = RequestMethod.GET)
	public void invoiceConsumerDetailForm(@PathVariable("merchantId") String merchantId,
			@PathVariable("invoiceCode") String invoiceCode, final Model model) {
		try {
			MerchantDTO merchant = merchantDetailsFetchService.getMerchantDetailsByMerchantId(merchantId);
			LOGGER.info("Render intermediate page request for merchant id {} and invoice code {}", merchantId,
					invoiceCode);
			getInvoiceModel.getInvoiceModelByInvoiceNumberAndMerchantId(invoiceCode, merchantId)
					.doOnSuccess(invoiceModel -> {
						if (CommonUtil.isNull(invoiceModel)) {
							throw new InvoiceException(Constants.FAILURE, "Invoice does not exist");
						}
						payRequestValidator.validate(invoiceModel);
						Map<String, Object> updateMap = new HashMap<String, Object>();
						updateMap.put("invoiceLinkStatus", "Link Clicked by User");
						updateInvoiceModel.update(invoiceModel, updateMap);
						model.addAttribute("payuCheckout",
								new StringBuilder(addPaymentApiUrl).append(merchantId).append("/").append(invoiceCode));
						model.addAttribute("amount", invoiceModel.getTotalAmount());
						model.addAttribute("Invoice Description", invoiceModel.getInvoiceDescription());
						model.addAttribute("currency", invoiceModel.getCurrency());
						model.addAttribute("consumerName", CommonUtil.isNull(invoiceModel.getUserDetails()) ? ""
								: invoiceModel.getUserDetails().getName());
						model.addAttribute("merchantName", merchant.getName());
						ServerResponse.ok().body(Mono.<String> just("payunowIntermediateWeb"), String.class);
					});
		} catch (Exception ex) {
			LOGGER.error("Exception while trying to render intermediate page", ex);
			throw new InvoiceException(Constants.FAILURE, "Rendering intermediate page failed");
		}
	}

}