package com.payunow.invoice.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentDTO {
	private String paymentId;
	private Integer paymentTypeId;
	private String paymentMerchantType;
	private Double totalAmount;
	private String lastStatus;
	private Integer merchantId;
	private String merchantTransactionId = "N/A";
	private Integer userId;
	private String addedOn;
	private String updatedOn;
	private String reconStatus;
	private String paymentTransactionIds;
	private String guid;
	private String parentPaymentId;
	private String purchaseFrom;
	private int autoReleased;
	private String requestedOn;
	private String succeedOn;
	private Double amountLeft;
	private Boolean riskApproved;
	private String paymentTypeName;
	private Double cashbackAccumulated;
	private Double cashbackUsed;
	private String frontEndPaymentStatus;
	private String merchantName;
	private Integer offerId;
	private String deliveryFiles;
	private String txnErrMessage;
	private String logo;
	private String merchantDisplayName;
	private String disputeStatus;
	private String merchantBusinessType;
	private String refundStatus;
	private String paymentDetails;
	private Integer disputeDays;
	private String settlementItemStatus;
	private String pageUrl;
	private String mobilePageUrl;
	private Boolean disableRequestRelease;

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public Integer getPaymentTypeId() {
		return paymentTypeId;
	}

	public void setPaymentTypeId(Integer paymentTypeId) {
		this.paymentTypeId = paymentTypeId;
	}

	public String getPaymentMerchantType() {
		return paymentMerchantType;
	}

	public void setPaymentMerchantType(String paymentMerchantType) {
		this.paymentMerchantType = paymentMerchantType;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getLastStatus() {
		return lastStatus;
	}

	public void setLastStatus(String lastStatus) {
		this.lastStatus = lastStatus;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantTransactionId() {
		return merchantTransactionId;
	}

	public void setMerchantTransactionId(String merchantTransactionId) {
		this.merchantTransactionId = merchantTransactionId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(String addedOn) {
		this.addedOn = addedOn;
	}

	public String getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(String updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getReconStatus() {
		return reconStatus;
	}

	public void setReconStatus(String reconStatus) {
		this.reconStatus = reconStatus;
	}

	public String getPaymentTransactionIds() {
		return paymentTransactionIds;
	}

	public void setPaymentTransactionIds(String paymentTransactionIds) {
		this.paymentTransactionIds = paymentTransactionIds;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getParentPaymentId() {
		return parentPaymentId;
	}

	public void setParentPaymentId(String parentPaymentId) {
		this.parentPaymentId = parentPaymentId;
	}

	public String getPurchaseFrom() {
		return purchaseFrom;
	}

	public void setPurchaseFrom(String purchaseFrom) {
		this.purchaseFrom = purchaseFrom;
	}

	public int getAutoReleased() {
		return autoReleased;
	}

	public void setAutoReleased(int autoReleased) {
		this.autoReleased = autoReleased;
	}

	public String getRequestedOn() {
		return requestedOn;
	}

	public void setRequestedOn(String requestedOn) {
		this.requestedOn = requestedOn;
	}

	public String getSucceedOn() {
		return succeedOn;
	}

	public void setSucceedOn(String succeedOn) {
		this.succeedOn = succeedOn;
	}

	public Double getAmountLeft() {
		return amountLeft;
	}

	public void setAmountLeft(Double amountLeft) {
		this.amountLeft = amountLeft;
	}

	public Boolean getRiskApproved() {
		return riskApproved;
	}

	public void setRiskApproved(Boolean riskApproved) {
		this.riskApproved = riskApproved;
	}

	public String getPaymentTypeName() {
		return paymentTypeName;
	}

	public void setPaymentTypeName(String paymentTypeName) {
		this.paymentTypeName = paymentTypeName;
	}

	public Double getCashbackAccumulated() {
		return cashbackAccumulated;
	}

	public void setCashbackAccumulated(Double cashbackAccumulated) {
		this.cashbackAccumulated = cashbackAccumulated;
	}

	public Double getCashbackUsed() {
		return cashbackUsed;
	}

	public void setCashbackUsed(Double cashbackUsed) {
		this.cashbackUsed = cashbackUsed;
	}

	public String getFrontEndPaymentStatus() {
		return frontEndPaymentStatus;
	}

	public void setFrontEndPaymentStatus(String frontEndPaymentStatus) {
		this.frontEndPaymentStatus = frontEndPaymentStatus;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public Integer getOfferId() {
		return offerId;
	}

	public void setOfferId(Integer offerId) {
		this.offerId = offerId;
	}

	public String getDeliveryFiles() {
		return deliveryFiles;
	}

	public void setDeliveryFiles(String deliveryFiles) {
		this.deliveryFiles = deliveryFiles;
	}

	public String getTxnErrMessage() {
		return txnErrMessage;
	}

	public void setTxnErrMessage(String txnErrMessage) {
		this.txnErrMessage = txnErrMessage;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getMerchantDisplayName() {
		return merchantDisplayName;
	}

	public void setMerchantDisplayName(String merchantDisplayName) {
		this.merchantDisplayName = merchantDisplayName;
	}

	public String getDisputeStatus() {
		return disputeStatus;
	}

	public void setDisputeStatus(String disputeStatus) {
		this.disputeStatus = disputeStatus;
	}

	public String getMerchantBusinessType() {
		return merchantBusinessType;
	}

	public void setMerchantBusinessType(String merchantBusinessType) {
		this.merchantBusinessType = merchantBusinessType;
	}

	public String getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(String refundStatus) {
		this.refundStatus = refundStatus;
	}

	public String getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(String paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	public Integer getDisputeDays() {
		return disputeDays;
	}

	public void setDisputeDays(Integer disputeDays) {
		this.disputeDays = disputeDays;
	}

	public String getSettlementItemStatus() {
		return settlementItemStatus;
	}

	public void setSettlementItemStatus(String settlementItemStatus) {
		this.settlementItemStatus = settlementItemStatus;
	}

	public String getPageUrl() {
		return pageUrl;
	}

	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}

	public String getMobilePageUrl() {
		return mobilePageUrl;
	}

	public void setMobilePageUrl(String mobilePageUrl) {
		this.mobilePageUrl = mobilePageUrl;
	}

	public Boolean getDisableRequestRelease() {
		return disableRequestRelease;
	}

	public void setDisableRequestRelease(Boolean disableRequestRelease) {
		this.disableRequestRelease = disableRequestRelease;
	}
}
