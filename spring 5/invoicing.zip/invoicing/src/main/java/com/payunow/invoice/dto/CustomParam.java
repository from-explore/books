package com.payunow.invoice.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class CustomParam {

	@JsonIgnore
	private int pos;
	private String name;
	private String value;

	public CustomParam(int pos, String name, String value) {
		this.setPos(pos);
		this.name = name;
		this.value = value;
	}

	public CustomParam() {
		this(0, null, null);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}
}
