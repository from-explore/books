package com.payunow.invoice.util;

import java.util.Date;
import java.util.Random;

public class RandomIdGenerator {

	private static final String INV_PREFIX = "INV";

	public static String generateInvoiceCode(char[] charset) {
		String currentTimeStamp = DateUtil.getMSDateString(new Date());
		Random number = new Random();
		int length = number.nextInt(5) + 8;
		Random random = new Random();
		String randomCode = "";
		for (int i = 0; i < length; i++) {
			int idx = random.nextInt(charset.length);
			randomCode += charset[idx];
		}
		String invoiceCode = INV_PREFIX + randomCode + currentTimeStamp;
		invoiceCode = invoiceCode.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", "").replace(".", "");
		return invoiceCode;
	}

}
