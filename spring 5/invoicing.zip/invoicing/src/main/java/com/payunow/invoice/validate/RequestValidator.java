package com.payunow.invoice.validate;

public interface RequestValidator<T> {

	public void validate(T t);

}
