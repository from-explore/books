package com.payunow.invoice.util;

import java.util.Date;

import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.model.Amount;
import com.payunow.invoice.model.InvoiceModel;
import com.payunow.invoice.request.payload.SingleInvoicePaymentRequest;
import com.payunow.invoice.type.Currency;
import com.payunow.invoice.type.InvoiceLinkStatus;

public class Transformer {

	public static InvoiceModel InvoiceModelFromSingleInvoicePaymentRequest(
			SingleInvoicePaymentRequest singleInvoicePaymentRequest, String shortUrl, String totalAmount) {

		InvoiceModel model = new InvoiceModel();
		model.setAmount(singleInvoicePaymentRequest.getAmount());
		model.setTotalAmount(totalAmount);
		model.setUserDetails(singleInvoicePaymentRequest.getUserDetails());
		model.setChannel(singleInvoicePaymentRequest.getChannel());
		model.setAddedOn(
				CommonUtil.isNull(singleInvoicePaymentRequest.getAddedOn()) ? DateUtil.getDefaultDateTime(new Date())
						: DateUtil.convertToIST(singleInvoicePaymentRequest.getAddedOn()));
		model.setCurrency(CommonUtil.isEmpty(singleInvoicePaymentRequest.getCurrency()) ? Currency.INR.toString()
				: singleInvoicePaymentRequest.getCurrency());
		model.setCustomParams(singleInvoicePaymentRequest.getCustomParams());
		model.setExpiryDate(CommonUtil.isNull(singleInvoicePaymentRequest.getExpiryDate())
				? DateUtil.addDaysToDate(model.getAddedOn(), 45)
				: DateUtil.convertToIST(singleInvoicePaymentRequest.getExpiryDate()));

		model.setInvoiceDescription(singleInvoicePaymentRequest.getInvoiceDescription());
		model.setInvoiceNumber(singleInvoicePaymentRequest.getInvoiceNumber());
		model.setInvoiceStatus(CommonUtil.isNull(singleInvoicePaymentRequest.getInvoiceStatus())
				? InvoiceLinkStatus.ACTIVE.toString() : singleInvoicePaymentRequest.getInvoiceStatus());
		model.setMaxPaymentsAllowed(CommonUtil.isNull(singleInvoicePaymentRequest.getMaxPaymentsAllowed()) ? 0
				: singleInvoicePaymentRequest.getMaxPaymentsAllowed());
		model.setNotifyThirdPartyDetails(singleInvoicePaymentRequest.getNotify());
		model.setRecurringInvoiceDetail(singleInvoicePaymentRequest.getRecurring());
		model.setShortenedUrl(shortUrl);
		model.setMerchantId(singleInvoicePaymentRequest.getMerchantId());
		model.setSuccesfulPaymentsCount(0);
		model.setCartAndShippingDetails(singleInvoicePaymentRequest.getCartAndShippingDetails());

		return model;

	}

	public static Amount truncateAmountFields(SingleInvoicePaymentRequest singleInvoicePaymentRequest) {
		String tax = CommonUtil.isEmpty(singleInvoicePaymentRequest.getAmount().getTax()) ? "0.00"
				: singleInvoicePaymentRequest.getAmount().getTax();
		String discount = CommonUtil.isEmpty(singleInvoicePaymentRequest.getAmount().getDiscount()) ? "0.00"
				: singleInvoicePaymentRequest.getAmount().getDiscount();
		String shipping = CommonUtil.isEmpty(singleInvoicePaymentRequest.getAmount().getShippingCharge()) ? "0.00"
				: singleInvoicePaymentRequest.getAmount().getShippingCharge();
		String subAmount = CommonUtil.isEmpty(singleInvoicePaymentRequest.getAmount().getSubAmount()) ? "0.00"
				: singleInvoicePaymentRequest.getAmount().getSubAmount();
		String totalAmount = "" + ((Double.parseDouble(tax) + Double.parseDouble(shipping)
				+ Double.parseDouble(subAmount) - Double.parseDouble(discount)) * 100.00) / 100;
		if (CommonUtil.safeParseDouble(totalAmount) < 0) {
			throw new InvoiceException(Constants.FAILURE, "Invalid Total Amount, Amount cannot be negative");
		}
		String roundedOffTax = CommonUtil.formatTwoDecimalPlaces(Double.parseDouble(tax));
		String roundedOffDiscount = CommonUtil.formatTwoDecimalPlaces(Double.parseDouble(discount));
		String roundedOffShipping = CommonUtil.formatTwoDecimalPlaces(Double.parseDouble(shipping));
		String roundedOffSubAmount = CommonUtil.formatTwoDecimalPlaces(Double.parseDouble(subAmount));
		return new Amount(roundedOffTax.equals("0.00") ? null : roundedOffTax,
				roundedOffDiscount.equals("0.00") ? null : roundedOffDiscount,
				roundedOffShipping.equals("0.00") ? null : roundedOffShipping,
				roundedOffSubAmount.equals("0.00") ? null : roundedOffSubAmount);
	}

	public static String calculateTotalAmount(SingleInvoicePaymentRequest singleInvoicePaymentRequest) {
		String tax = CommonUtil.isEmpty(singleInvoicePaymentRequest.getAmount().getTax()) ? "0.00"
				: singleInvoicePaymentRequest.getAmount().getTax();
		String discount = CommonUtil.isEmpty(singleInvoicePaymentRequest.getAmount().getDiscount()) ? "0.00"
				: singleInvoicePaymentRequest.getAmount().getDiscount();
		String shipping = CommonUtil.isEmpty(singleInvoicePaymentRequest.getAmount().getShippingCharge()) ? "0.00"
				: singleInvoicePaymentRequest.getAmount().getShippingCharge();
		String subAmount = CommonUtil.isEmpty(singleInvoicePaymentRequest.getAmount().getSubAmount()) ? "0.00"
				: singleInvoicePaymentRequest.getAmount().getSubAmount();
		String totalAmount = "" + ((Double.parseDouble(tax) + Double.parseDouble(shipping)
				+ Double.parseDouble(subAmount) - Double.parseDouble(discount)) * 100.00) / 100;
		if (CommonUtil.safeParseDouble(totalAmount) < 0) {
			throw new InvoiceException(Constants.FAILURE, "Invalid Total Amount, Amount cannot be negative");
		}
		String roundedOffTotalAmount = CommonUtil.formatTwoDecimalPlaces(Double.parseDouble(totalAmount));
		return roundedOffTotalAmount.equals("0.00") ? null : roundedOffTotalAmount;
	}

}