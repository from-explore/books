package com.payunow.invoice.dto;

public class InvoiceSearchResponseDTO {
	private String addedOn;
	private String invoicenumber;
	private String invoiceDescription;
	private String amount;
	private String status;

	public InvoiceSearchResponseDTO(String addedOn, String invoicenumber, String invoiceDescription, String amount,
			String status) {
		super();
		this.addedOn = addedOn;
		this.invoicenumber = invoicenumber;
		this.invoiceDescription = invoiceDescription;
		this.amount = amount;
		this.status = status;
	}

	public String getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(String addedOn) {
		this.addedOn = addedOn;
	}

	public String getInvoicenumber() {
		return invoicenumber;
	}

	public void setInvoicenumber(String invoicenumber) {
		this.invoicenumber = invoicenumber;
	}

	public String getInvoiceDescription() {
		return invoiceDescription;
	}

	public void setInvoiceDescription(String invoiceDescription) {
		this.invoiceDescription = invoiceDescription;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
