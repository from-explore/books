package com.payunow.invoice.validate;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.model.InvoiceModel;
import com.payunow.invoice.type.InvoiceLinkStatus;
import com.payunow.invoice.util.Constants;

@Component
@Order(2)
public class isInvoiceActive implements RequestValidator<InvoiceModel> {

	@Override
	public void validate(InvoiceModel t) {
		if (InvoiceLinkStatus.INACTIVE.toString().equalsIgnoreCase(t.getInvoiceStatus())) {
			throw new InvoiceException(Constants.FAILURE, "Invoice is not ACTIVE");
		}
	}

}
