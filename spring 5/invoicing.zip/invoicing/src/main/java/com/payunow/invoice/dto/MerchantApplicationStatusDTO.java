package com.payunow.invoice.dto;

public class MerchantApplicationStatusDTO {
	private Integer id;

	private Integer merchantId;

	private Integer nodal;

	private Integer agreement;

	private Integer highRiskCategory;

	private Integer websiteAvailable;

	private Integer businessDetails;

	private Integer bankAccountDetails;

	private Integer merchant;

	private Integer contactDetails;

	private Integer businessEmailVerification;

	private Integer businessPhoneVerification;

	private Integer bankVerification;

	private String hasWebsite;

	private Integer appStatus;

	private Integer holdSettlement;

	private Integer businessLineStatus;

	private Integer merchantOnBoardingStatus;

	private Integer merchantRiskStatus;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public Integer getNodal() {
		return nodal;
	}

	public void setNodal(Integer nodal) {
		this.nodal = nodal;
	}

	public Integer getAgreement() {
		return agreement;
	}

	public void setAgreement(Integer agreement) {
		this.agreement = agreement;
	}

	public Integer getHighRiskCategory() {
		return highRiskCategory;
	}

	public void setHighRiskCategory(Integer highRiskCategory) {
		this.highRiskCategory = highRiskCategory;
	}

	public Integer getWebsiteAvailable() {
		return websiteAvailable;
	}

	public void setWebsiteAvailable(Integer websiteAvailable) {
		this.websiteAvailable = websiteAvailable;
	}

	public Integer getBusinessDetails() {
		return businessDetails;
	}

	public void setBusinessDetails(Integer businessDetails) {
		this.businessDetails = businessDetails;
	}

	public Integer getMerchant() {
		return merchant;
	}

	public void setMerchant(Integer merchant) {
		this.merchant = merchant;
	}

	public Integer getContactDetails() {
		return contactDetails;
	}

	public void setContactDetails(Integer contactDetails) {
		this.contactDetails = contactDetails;
	}

	public Integer getBusinessEmailVerification() {
		return businessEmailVerification;
	}

	public void setBusinessEmailVerification(Integer businessEmailVerification) {
		this.businessEmailVerification = businessEmailVerification;
	}

	public Integer getBusinessPhoneVerification() {
		return businessPhoneVerification;
	}

	public void setBusinessPhoneVerification(Integer businessPhoneVerification) {
		this.businessPhoneVerification = businessPhoneVerification;
	}

	public Integer getBankAccountDetails() {
		return bankAccountDetails;
	}

	public void setBankAccountDetails(Integer bankDetails) {
		this.bankAccountDetails = bankDetails;
	}

	public Integer getBankVerification() {
		return bankVerification;
	}

	public void setBankVerification(Integer bankVerificationStatus) {
		this.bankVerification = bankVerificationStatus;
	}

	public String getHasWebsite() {
		return hasWebsite;
	}

	public void setHasWebsite(String hasWebsite) {
		this.hasWebsite = hasWebsite;
	}

	public Integer getAppStatus() {
		return appStatus;
	}

	public void setAppStatus(Integer appStatus) {
		this.appStatus = appStatus;
	}

	public Integer getHoldSettlement() {
		return holdSettlement;
	}

	public void setHoldSettlement(Integer holdSettlement) {
		this.holdSettlement = holdSettlement;
	}

	public Integer getBusinessLineStatus() {
		return businessLineStatus;
	}

	public void setBusinessLineStatus(Integer businessLineStatus) {
		this.businessLineStatus = businessLineStatus;
	}

	public Integer getMerchantOnBoardingStatus() {
		return merchantOnBoardingStatus;
	}

	public void setMerchantOnBoardingStatus(Integer merchantOnBoardingStatus) {
		this.merchantOnBoardingStatus = merchantOnBoardingStatus;
	}

	public Integer getMerchantRiskStatus() {
		return merchantRiskStatus;
	}

	public void setMerchantRiskStatus(Integer merchantRiskStatus) {
		this.merchantRiskStatus = merchantRiskStatus;
	}

}
