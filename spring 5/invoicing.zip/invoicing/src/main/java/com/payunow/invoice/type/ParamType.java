package com.payunow.invoice.type;

public enum ParamType {
	STRING, INT, DOUBLE
}