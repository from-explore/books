package com.payunow.invoice.validate;

import java.util.Date;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;

@Component
@Order(6)
public class IsValidExpiryDate implements RequestValidator<SinglePaymentInvoice> {

	@Override
	public void validate(SinglePaymentInvoice t) {
		if (CommonUtil.isNotNull(t.getSingleInvoicePaymentRequest().getExpiryDate())
				&& CommonUtil.isNotNull(t.getSingleInvoicePaymentRequest().getAddedOn())) {
			if (t.getSingleInvoicePaymentRequest().getExpiryDate()
					.compareTo(t.getSingleInvoicePaymentRequest().getAddedOn()) <= 0) {
				throw new InvoiceException(Constants.FAILURE, "Invalid Expiry Date, Expiry less than ");
			}
		}
		if (CommonUtil.isNotNull(t.getSingleInvoicePaymentRequest().getExpiryDate())
				&& CommonUtil.isNull(t.getSingleInvoicePaymentRequest().getAddedOn())) {
			if (t.getSingleInvoicePaymentRequest().getExpiryDate()
					.compareTo(new Date()) <= 0) {
				throw new InvoiceException(Constants.FAILURE, "Invalid Expiry Date, Expiry less than Invoice Creation date");
			}
		}

	}

}
