package com.payunow.invoice.dto;

import java.util.Date;

public class AccountDTO {

	private Integer id;
	private Integer entityId;
	private String bankName;
	private String entityType;
	private String number;
	private String holderName;
	private String branchCity;
	private String branchState;
	private String branchName;
	private String ifscCode;
	private String pennyTotalAmount;
	private String accountType;
	private String panCardNo;
	private String nameOnPanCard;
	private String branchAddress;
	private String activationStatus;
	private Date created;
	private Date updated;
	private Integer pennyStatus;
	private Integer ifscStatus;
	private Integer panStatus;
	private Integer bankVerification;
	private String pennyDepositClickedOn;
	private Date ifscStatusUpdatedOn;
	private Date panStatusUpdatedOn;
	private Date pennyStatusUpdatedOn;
	private String utrNumber;
	private MerchantBusinessDetailDTO merchantBusinessDetailDTO;
	private Integer merchantOnBoardingStatus;
	private Integer pennyVerificationAttemptsLeft;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getEntityId() {
		return entityId;
	}

	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getAccountNumber() {
		return number;
	}

	public void setAccountNumber(String accountNumber) {
		this.number = accountNumber;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getBranchCity() {
		return branchCity;
	}

	public void setBranchCity(String branchCity) {
		this.branchCity = branchCity;
	}

	public String getBranchState() {
		return branchState;
	}

	public void setBranchState(String branchState) {
		this.branchState = branchState;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getPennyTotalAmount() {
		return pennyTotalAmount;
	}

	public void setPennyTotalAmount(String pennyTotalAmount) {
		this.pennyTotalAmount = pennyTotalAmount;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getPanCardNo() {
		return panCardNo;
	}

	public void setPanCardNo(String panCardNo) {
		this.panCardNo = panCardNo;
	}

	public String getNameOnPanCard() {
		return nameOnPanCard;
	}

	public void setNameOnPanCard(String nameOnPanCard) {
		this.nameOnPanCard = nameOnPanCard;
	}

	public String getBranchAddress() {
		return branchAddress;
	}

	public void setBranchAddress(String branchAddress) {
		this.branchAddress = branchAddress;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getActivationStatus() {
		return activationStatus;
	}

	public void setActivationStatus(String activationStatus) {
		this.activationStatus = activationStatus;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public Integer getPennyStatus() {
		return pennyStatus;
	}

	public void setPennyStatus(Integer pennyStatus) {
		this.pennyStatus = pennyStatus;
	}

	public Integer getIfscStatus() {
		return ifscStatus;
	}

	public void setIfscStatus(Integer ifscStatus) {
		this.ifscStatus = ifscStatus;
	}

	public Integer getPanStatus() {
		return panStatus;
	}

	public void setPanStatus(Integer panStatus) {
		this.panStatus = panStatus;
	}

	public Integer getBankVerificationStatus() {
		return bankVerification;
	}

	public void setBankVerificationStatus(Integer bankVerificationStatus) {
		this.bankVerification = bankVerificationStatus;
	}

	public String getPennyDepositClickedOn() {
		return pennyDepositClickedOn;
	}

	public void setPennyDepositClickedOn(String pennyDepositClickedOn) {
		this.pennyDepositClickedOn = pennyDepositClickedOn;
	}

	public Date getIfscStatusUpdatedOn() {
		return ifscStatusUpdatedOn;
	}

	public void setIfscStatusUpdatedOn(Date ifscStatusUpdatedOn) {
		this.ifscStatusUpdatedOn = ifscStatusUpdatedOn;
	}

	public Date getPanStatusUpdatedOn() {
		return panStatusUpdatedOn;
	}

	public void setPanStatusUpdatedOn(Date panStatusUpdatedOn) {
		this.panStatusUpdatedOn = panStatusUpdatedOn;
	}

	public Date getPennyStatusUpdatedOn() {
		return pennyStatusUpdatedOn;
	}

	public void setPennyStatusUpdatedOn(Date pennyStatusUpdatedOn) {
		this.pennyStatusUpdatedOn = pennyStatusUpdatedOn;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getUtrNumber() {
		return utrNumber;
	}

	public void setUtrNumber(String utrNumber) {
		this.utrNumber = utrNumber;
	}

	public Integer getMerchantOnBoardingStatus() {
		return merchantOnBoardingStatus;
	}

	public void setMerchantOnBoardingStatus(Integer merchantOnBoardingStatus) {
		this.merchantOnBoardingStatus = merchantOnBoardingStatus;
	}

	public Integer getPennyVerificationAttemptsLeft() {
		return pennyVerificationAttemptsLeft;
	}

	public void setPennyVerificationAttemptsLeft(Integer pennyVerificationAttemptsLeft) {
		this.pennyVerificationAttemptsLeft = pennyVerificationAttemptsLeft;
	}

	public MerchantBusinessDetailDTO getMerchantBusinessDetailDTO() {
		return merchantBusinessDetailDTO;
	}

	public void setMerchantBusinessDetailDTO(MerchantBusinessDetailDTO merchantBusinessDetailDTO) {
		this.merchantBusinessDetailDTO = merchantBusinessDetailDTO;
	}

}
