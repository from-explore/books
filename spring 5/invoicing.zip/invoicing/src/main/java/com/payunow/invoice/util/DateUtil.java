package com.payunow.invoice.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateUtil {

	public final static String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
	public final static String DEFAULT_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	private final static String MS_DATE_FORMAT = "yy-MM-dd HH:mm:ss";
	private final static String DATE_FORMAT = "yy-MM-dd";

	public static String getMSDateString(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		return sdf.format(date);
	}

	public static String getDateString(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat(MS_DATE_FORMAT);
		return sdf.format(date);
	}

	public static String getDefaultDateTime(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat(DEFAULT_DATE_TIME_FORMAT);
		return sdf.format(date);
	}

	public static String getDefaultDate(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat(DEFAULT_DATE_FORMAT);
		return sdf.format(date);
	}

	public static Date getDate(String stringDate) {
		DateFormat defaultFormat = new SimpleDateFormat(DEFAULT_DATE_TIME_FORMAT, Locale.ENGLISH);
		try {
			Date date = defaultFormat.parse(stringDate);
			return date;
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	public static String addDaysToDate(String originalDate, int numOfDays) {
		DateFormat defaultFormat = new SimpleDateFormat(DEFAULT_DATE_TIME_FORMAT, Locale.ENGLISH);
		Date date = null;
		try {
			date = defaultFormat.parse(originalDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SimpleDateFormat sdf = new SimpleDateFormat(DEFAULT_DATE_TIME_FORMAT);
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.DATE, 45);
		String dt = sdf.format(c.getTime());
		return dt;
	}

	public static String convertToIST(Date date) {
		DateFormat defaultFormat = new SimpleDateFormat(DEFAULT_DATE_TIME_FORMAT);
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.HOUR, -5);
		c.add(Calendar.MINUTE, -30);
		String dt = defaultFormat.format(c.getTime());
		return dt;
	}

}