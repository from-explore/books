package com.payunow.invoice.validate;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.type.InvoiceLinkStatus;
import com.payunow.invoice.util.Constants;

@Component
@Order(7)
public class IsValidInvoiceStatus implements RequestValidator<SinglePaymentInvoice> {

	@Override
	public void validate(SinglePaymentInvoice t) {
		try {
			InvoiceLinkStatus.valueOf(t.getSingleInvoicePaymentRequest().getInvoiceStatus());
		} catch (Exception ex) {
			throw new InvoiceException(Constants.FAILURE,
					"Invalid Invoice Status :" + t.getSingleInvoicePaymentRequest().getInvoiceStatus());
		}
	}

}
