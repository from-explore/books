package com.payunow.invoice.type;

public enum RequestType {

	SIGNATURE, LAYOUT, FETCH;
}
