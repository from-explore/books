package com.payunow.invoice.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.payunow.invoice.dto.TinyRequest;
import com.payunow.invoice.dto.TinyResponse;
import com.payunow.invoice.exception.InvoiceException;

import reactor.core.publisher.Mono;

@Component
public class UrlShortner {

	private final static Logger LOGGER = LoggerFactory.getLogger(UrlShortner.class);

	@Value("${tiny.payu.url}")
	private String payuShorternUrl;

	public String shortenThroughCitrus(String paymentUrl) {
		try {
			LOGGER.info("Shortening payment url with original url {}", paymentUrl);
			WebClient client = WebClient.create();
			String requestBody = "{\"destination\" : \"" + paymentUrl + "\"}";
			Mono<String> urlShortenerResponse = client.post().uri(payuShorternUrl)
					.contentType(MediaType.APPLICATION_JSON_UTF8).syncBody(requestBody).exchange()
					.flatMap(response -> response.bodyToMono(String.class));
			urlShortenerResponse.doOnSuccess(urlShortenerResp -> {
				LOGGER.info("Shortened payment url {}", urlShortenerResp);
			});
			urlShortenerResponse.doOnError(error -> {
				LOGGER.error("Error while shortening payment url with original url {}", paymentUrl, error);
			});
			return urlShortenerResponse.block();
		} catch (Exception e) {
			LOGGER.error("Error while shortening payment url with original url {}", paymentUrl, e);
			throw new InvoiceException(Constants.FAILURE, "SMS Trigger Failed.");
		}
	}

	public TinyResponse shortenThroughCitrusBulk(TinyRequest tinyRequest) {
		try {
			LOGGER.info("Shortening payment urls in bulk with request param {}", tinyRequest.getDestination());
			WebClient client = WebClient.create();
			Mono<TinyResponse> urlShortenerResponse = client.post().uri(payuShorternUrl + "Bulk")
					.contentType(MediaType.APPLICATION_JSON_UTF8).syncBody(tinyRequest).exchange()
					.flatMap(response -> response.bodyToMono(TinyResponse.class));
			urlShortenerResponse.doOnSuccess(urlShortenerResp -> {
				LOGGER.info("Shortened payment url {}", urlShortenerResp);
			});
			urlShortenerResponse.doOnError(error -> {
				LOGGER.error("Error while shortening payment urls in bulk", error);
			});
			return urlShortenerResponse.block();
		} catch (Exception e) {
			LOGGER.error("Error while shortening payment urls in bulk", e);
			throw new InvoiceException(Constants.FAILURE, "Bulk Shortening Failed.");
		}
	}

}