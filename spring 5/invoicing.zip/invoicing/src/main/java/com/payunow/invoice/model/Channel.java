package com.payunow.invoice.model;

import java.io.Serializable;

import org.bson.Document;

public class Channel implements Serializable {

	/**
	 * @author manan.khandelwal
	 */

	private static final long serialVersionUID = 1L;

	private Boolean viaSms;
	private Boolean viaEmail;

	public Channel(Boolean viaSms, Boolean viaEmail) {
		super();
		this.viaSms = viaSms;
		this.viaEmail = viaEmail;
	}

	public Channel() {
	}

	public Boolean getViaSms() {
		return viaSms;
	}

	public void setViaSms(Boolean viaSms) {
		this.viaSms = viaSms;
	}

	public Boolean getViaEmail() {
		return viaEmail;
	}

	public void setViaEmail(Boolean viaEmail) {
		this.viaEmail = viaEmail;
	}

	public static Channel getChannelDetails(Document document) {
			try {
				Channel channel = new Channel(document.getBoolean("viaSms"), document.getBoolean("viaEmail"));
				return channel;
			} catch (Exception e) {
				return null;
			}
	}

}
