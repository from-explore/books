package com.payunow.invoice.request.payload;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotNull;

import com.payunow.invoice.model.Amount;
import com.payunow.invoice.model.CartAndShippingDetails;
import com.payunow.invoice.model.Channel;
import com.payunow.invoice.model.NotifyThirdParty;
import com.payunow.invoice.model.RecurringInvoiceDetail;
import com.payunow.invoice.model.UserDetails;

public class SingleInvoicePaymentRequest {

	private String invoiceNumber;

	@NotNull
	private String merchantId;

	@NotNull
	private String invoiceDescription;

	private String currency;

	private UserDetails userDetails;

	private Amount amount;

	private Date addedOn;

	private Date expiryDate;

	private String invoiceStatus;

	private Integer maxPaymentsAllowed; // in case of reusable links default
	// value = 1
	private CartAndShippingDetails cartAndShippingDetails;

	private Channel channel;

	@NotNull
	private String signature;

	private Map<String, String> customParams;
	private RecurringInvoiceDetail recurring;
	private List<NotifyThirdParty> notify;
	private boolean bulkRequest;

	public SingleInvoicePaymentRequest(String invoiceNumber, String merchantId, String invoiceDescription,
			String currency, UserDetails userDetails, Amount amount, Date addedOn, Date expiryDate,
			String invoiceStatus, Integer maxPaymentsAllowed, CartAndShippingDetails cartAndShippingDetails,
			Channel channel, String signature, Map<String, String> customParams, RecurringInvoiceDetail recurring,
			List<NotifyThirdParty> notify, boolean bulkRequest) {
		super();
		this.invoiceNumber = invoiceNumber;
		this.merchantId = merchantId;
		this.invoiceDescription = invoiceDescription;
		this.currency = currency;
		this.userDetails = userDetails;
		this.amount = amount;
		this.addedOn = addedOn;
		this.expiryDate = expiryDate;
		this.invoiceStatus = invoiceStatus;
		this.maxPaymentsAllowed = maxPaymentsAllowed;
		this.cartAndShippingDetails = cartAndShippingDetails;
		this.channel = channel;
		this.signature = signature;
		this.customParams = customParams;
		this.recurring = recurring;
		this.notify = notify;
		this.bulkRequest = bulkRequest;
	}

	public SingleInvoicePaymentRequest() {

	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getInvoiceDescription() {
		return invoiceDescription;
	}

	public void setInvoiceDescription(String invoiceDescription) {
		this.invoiceDescription = invoiceDescription;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

	public Amount getAmount() {
		return amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Integer getMaxPaymentsAllowed() {
		return maxPaymentsAllowed;
	}

	public void setMaxPaymentsAllowed(Integer maxPaymentsAllowed) {
		this.maxPaymentsAllowed = maxPaymentsAllowed;
	}

	public Channel getChannel() {
		return channel;
	}

	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public Map<String, String> getCustomParams() {
		return customParams;
	}

	public void setCustomParams(Map<String, String> customParams) {
		this.customParams = customParams;
	}

	public RecurringInvoiceDetail getRecurring() {
		return recurring;
	}

	public void setRecurring(RecurringInvoiceDetail recurring) {
		this.recurring = recurring;
	}

	public List<NotifyThirdParty> getNotify() {
		return notify;
	}

	public void setNotify(List<NotifyThirdParty> notify) {
		this.notify = notify;
	}

	public boolean isBulkRequest() {
		return bulkRequest;
	}

	public void setBulkRequest(boolean bulkRequest) {
		this.bulkRequest = bulkRequest;
	}

	public String getInvoiceStatus() {
		return invoiceStatus;
	}

	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}

	@Override
	public String toString() {
		return "SingleInvoicePaymentRequest [invoiceNumber=" + invoiceNumber + ", merchantId=" + merchantId
				+ ", invoiceDescription=" + invoiceDescription + ", currency=" + currency + ", userDetails="
				+ userDetails + ", amount=" + amount + ", addedOn=" + addedOn + ", expiryDate=" + expiryDate
				+ ", invoiceStatus=" + invoiceStatus + ", maxPaymentsAllowed=" + maxPaymentsAllowed
				+ ", cartAndShippingDetails=" + cartAndShippingDetails + ", channel=" + channel + ", signature="
				+ signature + ", customParams=" + customParams + ", recurring=" + recurring + ", notify=" + notify
				+ ", bulkRequest=" + bulkRequest + "]";
	}

	public CartAndShippingDetails getCartAndShippingDetails() {
		return cartAndShippingDetails;
	}

	public void setCartAndShippingDetails(CartAndShippingDetails cartAndShippingDetails) {
		this.cartAndShippingDetails = cartAndShippingDetails;
	}

}