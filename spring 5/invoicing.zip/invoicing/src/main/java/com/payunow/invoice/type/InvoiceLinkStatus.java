package com.payunow.invoice.type;

public enum InvoiceLinkStatus {
	ACTIVE, INACTIVE, EXPIRED, active, inactive, expired
}
