package com.payunow.invoice.model;

import java.io.Serializable;
import java.util.Date;

import org.bson.Document;

public class RecurringInvoiceDetail implements Serializable {

	/**
	 * @author manan.khandelwal
	 */

	private static final long serialVersionUID = 1L;

	private Date startDate;
	private Date endDate;
	private String period;
	private Integer periodUnit;

	public RecurringInvoiceDetail(Date startDate, Date endDate, String period, Integer periodUnit) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.period = period;
		this.periodUnit = periodUnit;
	}

	public RecurringInvoiceDetail() {
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEnd_date(Date endDate) {
		this.endDate = endDate;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public Integer getPeriodUnit() {
		return periodUnit;
	}

	public void setPeriod_unit(Integer periodUnit) {
		this.periodUnit = periodUnit;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public static RecurringInvoiceDetail getReccuringDetails(Document document) {
		try {
			RecurringInvoiceDetail recurring = new RecurringInvoiceDetail(document.getDate("startDate"),
					document.getDate("endDate"), document.getString("period"), document.getInteger("periodUnit"));
			return recurring;
		} catch (Exception ex) {
			return null;
		}
	}

	@Override
	public String toString() {
		return "RecurringInvoiceDetail [startDate=" + startDate + ", endDate=" + endDate + ", period=" + period
				+ ", periodUnit=" + periodUnit + "]";
	}

}
