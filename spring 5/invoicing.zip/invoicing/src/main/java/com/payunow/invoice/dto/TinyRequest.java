package com.payunow.invoice.dto;

import java.util.List;

public class TinyRequest {
	
	private List<String> destination;

	public List<String> getDestination() {
		return destination;
	}

	public void setDestination(List<String> destination) {
		this.destination = destination;
	}

}
