package com.payunow.invoice.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

public class Tax implements Serializable {

	/**
	 * @author manan.khandelwal
	 */

	private static final long serialVersionUID = 1L;

	private String taxDescription;
	private String taxPercent;
	private String taxAmount;

	public Tax(String taxDescription, String taxPercent, String taxAmount) {
		super();
		this.taxDescription = taxDescription;
		this.taxPercent = taxPercent;
		this.taxAmount = taxAmount;
	}

	public Tax() {
	}

	public String getTaxDescription() {
		return taxDescription;
	}

	public void setTaxDescription(String tax_description) {
		this.taxDescription = tax_description;
	}

	public String getTaxPercent() {
		return taxPercent;
	}

	public void setTaxPercent(String tax_percent) {
		this.taxPercent = tax_percent;
	}

	public String getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(String tax_amount) {
		this.taxAmount = tax_amount;
	}

	public static List<Tax> getTaxList(List<Document> list) {
		try {
			List<Tax> taxList = new ArrayList<Tax>();
			for (Document document : list) {
				Tax tax = new Tax(document.getString("taxDescription"), document.getString("taxPercent"),
						document.getString("taxAmount"));
				taxList.add(tax);
			}
			return taxList;
		} catch (Exception ex) {
			return null;
		}
	}
}
