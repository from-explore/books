package com.payunow.invoice.util;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Encryptor {

	protected static final Logger log = LoggerFactory.getLogger(Encryptor.class);

	public static String encrypt(String text, String secretKey) {
		byte[] key = secretKey.getBytes();
		SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
		try {
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, keySpec);
			byte[] encryptedTextBytes = cipher.doFinal(text.getBytes("UTF-8"));
			return toHexAscii(encryptedTextBytes);
		} catch (Exception ex) {
			log.info(text + " : " + ex.getMessage());
		}
		return null;
	}

	public static String decrypt(String encryptedText, String secretKey) {
		byte[] key = secretKey.getBytes();
		SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
		try {
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, keySpec);
			byte[] encryptedTextBytes = fromHexAscii(encryptedText);
			byte[] decryptedTextBytes = cipher.doFinal(encryptedTextBytes);
			return new String(decryptedTextBytes);
		} catch (Exception ex) {
			log.info(encryptedText + " : " + ex.getMessage());
		}
		return null;
	}

	private static byte[] fromHexAscii(String s) throws NumberFormatException {
		try {
			int len = s.length();
			if ((len % 2) != 0)
				throw new NumberFormatException("Hex ascii must be exactly two digits per byte.");

			int out_len = len / 2;
			byte[] out = new byte[out_len];
			int i = 0;
			StringReader sr = new StringReader(s);
			while (i < out_len) {
				int val = (16 * fromHexDigit(sr.read())) + fromHexDigit(sr.read());
				out[i++] = (byte) val;
			}
			return out;
		} catch (IOException e) {
			throw new InternalError("IOException reading from StringReader?!?!");
		}
	}

	private static int fromHexDigit(int c) throws NumberFormatException {
		if (c >= 0x30 && c < 0x3A)
			return c - 0x30;
		else if (c >= 0x41 && c < 0x47)
			return c - 0x37;
		else if (c >= 0x61 && c < 0x67)
			return c - 0x57;
		else
			throw new NumberFormatException('\'' + c + "' is not a valid hexadecimal digit.");
	}

	private static String toHexAscii(byte[] bytes) {
		int len = bytes.length;
		StringWriter sw = new StringWriter(len * 2);
		for (int i = 0; i < len; ++i)
			addHexAscii(bytes[i], sw);
		return sw.toString();
	}

	private static void addHexAscii(byte b, StringWriter sw) {
		int ub = unsignedPromote(b);
		int h1 = ub / 16;
		int h2 = ub % 16;
		sw.write(toHexDigit(h1));
		sw.write(toHexDigit(h2));
	}

	private static int unsignedPromote(byte b) {
		return b & 0xff;
	}

	private static char toHexDigit(int h) {
		char out;
		if (h <= 9)
			out = (char) (h + 0x30);
		else
			out = (char) (h + 0x37);
		return out;
	}

}
