package com.payunow.invoice.model;

import java.io.Serializable;

import org.bson.Document;

public class Address implements Serializable {

	/**
	 * @author manan.khandelwal
	 */

	private static final long serialVersionUID = 1L;

	private String addressStreet1;
	private String addressStreet2;
	private String addressCity;
	private String addressState;
	private String addressCountry;
	private String addressZip;

	public Address(String addressStreet1, String addressStreet2, String addressCity, String addressState,
			String addressCountry, String addressZip) {
		super();
		this.addressStreet1 = addressStreet1;
		this.addressStreet2 = addressStreet2;
		this.addressCity = addressCity;
		this.addressState = addressState;
		this.addressCountry = addressCountry;
		this.addressZip = addressZip;
	}

	public Address() {
	}

	public String getAddressStreet1() {
		return addressStreet1;
	}

	public void setAddressStreet1(String addressStreet1) {
		this.addressStreet1 = addressStreet1;
	}

	public String getAddressStreet2() {
		return addressStreet2;
	}

	public void setAddressStreet2(String addressStreet2) {
		this.addressStreet2 = addressStreet2;
	}

	public String getAddressCity() {
		return addressCity;
	}

	public void setAddressCity(String addressCity) {
		this.addressCity = addressCity;
	}

	public String getAddressState() {
		return addressState;
	}

	public void setAddressState(String addressState) {
		this.addressState = addressState;
	}

	public String getAddressCountry() {
		return addressCountry;
	}

	public void setAddressCountry(String addressCountry) {
		this.addressCountry = addressCountry;
	}

	public String getAddressZip() {
		return addressZip;
	}

	public void setAddressZip(String addressZip) {
		this.addressZip = addressZip;
	}

	public static Address getAddress(Document document) {
		Address address = new Address(document.getString("addressStreet1"), document.getString("addressStreet2"),
				document.getString("addressCity"), document.getString("addressState"),
				document.getString("addressCountry"), document.getString("addressZip"));
		return address;

	}

	@Override
	public String toString() {
		return "Address [addressStreet1=" + addressStreet1 + ", addressStreet2=" + addressStreet2 + ", addressCity="
				+ addressCity + ", addressState=" + addressState + ", addressCountry=" + addressCountry
				+ ", addressZip=" + addressZip + "]";
	}

}
