package com.payunow.invoice.dto;

import java.util.List;

public class InvoiceSearchApiResponseDTO {

	private String errorMessage;

	private String errorCode;

	private List<InvoiceSearchResponseDTO> invoiceSearchResponse;

	public InvoiceSearchApiResponseDTO(String errorMessage, String errorCode,
			List<InvoiceSearchResponseDTO> invoiceSearchResponse) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.invoiceSearchResponse = invoiceSearchResponse;
	}

	public InvoiceSearchApiResponseDTO() {

	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public List<InvoiceSearchResponseDTO> getInvoiceSearchResponse() {
		return invoiceSearchResponse;
	}

	public void setInvoiceSearchResponse(List<InvoiceSearchResponseDTO> invoiceSearchResponse) {
		this.invoiceSearchResponse = invoiceSearchResponse;
	}

}
