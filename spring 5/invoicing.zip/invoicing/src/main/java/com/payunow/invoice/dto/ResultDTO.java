package com.payunow.invoice.dto;

import org.springframework.http.HttpStatus;

public class ResultDTO {

	private Integer status;
	private String message;
	private PaymentDTO result;
	private HttpStatus httpStatus;
	private Integer errorCode;

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}

	private String responseCode;

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public PaymentDTO getResult() {
		return this.result;
	}

	public void setResult(PaymentDTO result) {
		this.result = result;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
}
