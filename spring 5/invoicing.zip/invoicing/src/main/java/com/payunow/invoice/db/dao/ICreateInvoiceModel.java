package com.payunow.invoice.db.dao;

import org.springframework.stereotype.Service;

import com.payunow.invoice.model.InvoiceModel;

import reactor.core.publisher.Mono;

/**
 * Reactive implementation of creating invoices service.
 * 
 * @author nishant
 *
 */
@Service
public interface ICreateInvoiceModel {

	/**
	 * Create an invoice.
	 * 
	 * @param model
	 * 
	 * @return Mono<InvoiceModel>
	 */
	public Mono<InvoiceModel> create(InvoiceModel model);

}
