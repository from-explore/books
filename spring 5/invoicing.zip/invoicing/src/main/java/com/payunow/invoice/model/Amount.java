package com.payunow.invoice.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.bson.Document;

public class Amount implements Serializable {

	/**
	 * @author manan.khandelwal
	 */

	private static final long serialVersionUID = 1L;

	private String tax;
	private String discount;
	private String shippingCharge;

	@NotNull
	private String subAmount;

	public Amount(String tax, String discount, String shippingCharge, String subAmount) {
		super();
		this.tax = tax;
		this.discount = discount;
		this.shippingCharge = shippingCharge;
		this.subAmount = subAmount;
	}

	public Amount() {
	}

	public String getTax() {
		return tax;
	}

	public void setTax(String tax) {
		this.tax = tax;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getShippingCharge() {
		return shippingCharge;
	}

	public void setShippingCharge(String shipping_charge) {
		this.shippingCharge = shipping_charge;
	}

	public String getSubAmount() {
		return subAmount;
	}

	public void setSubAmount(String amount) {
		this.subAmount = amount;
	}

	public static Amount getAmount(Document document) {
		try {
			Amount amount = new Amount(document.getString("tax"), document.getString("discount"),
					document.getString("shippingCharge"), document.getString("amount"));
			return amount;
		} catch (Exception ex) {
			return null;
		}
	}

	@Override
	public String toString() {
		return "Amount [tax=" + tax + ", discount=" + discount + ", shippingCharge=" + shippingCharge + ", subAmount="
				+ subAmount + "]";
	}

}