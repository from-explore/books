package com.payunow.invoice.validate;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;

@Component
@Order(9)
public class IsValidCustomParameters implements RequestValidator<SinglePaymentInvoice> {

	@Override
	public void validate(SinglePaymentInvoice t) {
		if (CommonUtil.isNotNull(t.getSingleInvoicePaymentRequest().getCustomParams())
				&& t.getSingleInvoicePaymentRequest().getCustomParams().size() > 15) {
			throw new InvoiceException(Constants.FAILURE, "Custom Parameters size cannot be greater than 15");
		}
	}

}
