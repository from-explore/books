package com.payunow.invoice.service;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.payunow.invoice.db.dao.ICreateInvoiceModel;
import com.payunow.invoice.db.dao.IGetInvoiceModel;
import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.dto.MerchantDTO;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.model.InvoiceModel;
import com.payunow.invoice.request.payload.SingleInvoicePaymentRequest;
import com.payunow.invoice.type.InvoiceLinkStatus;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;
import com.payunow.invoice.util.MessagingUtil;
import com.payunow.invoice.util.PayuMoneyUrlShortener;
import com.payunow.invoice.util.RandomIdGenerator;
import com.payunow.invoice.util.Transformer;
import com.payunow.invoice.validate.SingleInvoiceRequestValidator;

import reactor.core.publisher.Mono;

@Service
public class InvoiceService {

	@Value("${payunow.invoice.baseUrl}")
	private String invoiceBaseUrl;

	@Autowired
	private SingleInvoiceRequestValidator invReqValidator;

	@Autowired
	private PayuMoneyUrlShortener urlShortner;

	@Autowired
	private IGetInvoiceModel getInvoiceModel;

	@Autowired
	private ICreateInvoiceModel createInvoiceModel;

	@Autowired
	private MessagingUtil messagingUtil;

	@Autowired
	private MerchantDetailsFetchService merchantDetailsFetchService;

	private final static Logger LOGGER = LoggerFactory.getLogger(InvoiceService.class);

	private String getInvoicePayUrl(SinglePaymentInvoice singlePaymentInvoice) {
		return invoiceBaseUrl + "/invoice/" + singlePaymentInvoice.getMerchant().getMerchantId() + "/"
				+ singlePaymentInvoice.getSingleInvoicePaymentRequest().getInvoiceNumber();
	}

	public Mono<String> createSingleInvoicingLink(SingleInvoicePaymentRequest invRequest) {
		final SingleInvoicePaymentRequest piRequest = CommonUtil.SanitizeSingleInvoiceRequest(invRequest);
		LOGGER.info("Request after trimming is : {}", piRequest.toString());
		final MerchantDTO merchant = merchantDetailsFetchService
				.getMerchantDetailsByMerchantId(piRequest.getMerchantId());
		InvoiceModel dbModel = CommonUtil.isNull(piRequest.getInvoiceNumber()) ? null
				: getInvoiceModel.getInvoiceModelByInvoiceNumberAndMerchantId(piRequest.getInvoiceNumber(),
						piRequest.getMerchantId()).block();
		final SinglePaymentInvoice singlePaymentInvoice = new SinglePaymentInvoice();
		singlePaymentInvoice.setSingleInvoicePaymentRequest(piRequest);
		singlePaymentInvoice.setMerchant(merchant);
		checkAndSetInvoiceCode(singlePaymentInvoice, dbModel);
		checkAndSetLinkExpiryStatus(singlePaymentInvoice);
		invReqValidator.validate(singlePaymentInvoice);
		String totalAmount = Transformer.calculateTotalAmount(piRequest);
		String paymentUrl = getInvoicePayUrl(singlePaymentInvoice);
		Mono<String> shortPaymentUrl = urlShortner.shortenUrl(paymentUrl);
		shortPaymentUrl.doOnSuccess(urlShortenerResp -> {
			InvoiceModel model = Transformer.InvoiceModelFromSingleInvoicePaymentRequest(
					singlePaymentInvoice.getSingleInvoicePaymentRequest(), urlShortenerResp, totalAmount);
			createInvoiceModel.create(model);
			messagingUtil.pushPaymentLinksViaChannels(singlePaymentInvoice.getSingleInvoicePaymentRequest(),
					urlShortenerResp, merchant.getName(), totalAmount);
			LOGGER.info("Shortened payment url {} for original url {}", urlShortenerResp, paymentUrl);
		});
		return shortPaymentUrl;
	}

	private void checkAndSetLinkExpiryStatus(SinglePaymentInvoice singlePaymentInvoice) {
		if (CommonUtil.isEmpty(singlePaymentInvoice.getSingleInvoicePaymentRequest().getInvoiceStatus())) {
			singlePaymentInvoice.getSingleInvoicePaymentRequest().setInvoiceStatus(InvoiceLinkStatus.ACTIVE.toString());
		}
	}

	private void checkAndSetInvoiceCode(SinglePaymentInvoice singlePaymentInvoice, InvoiceModel model) {
		if (CommonUtil.isNotNull(model)) {
			throw new InvoiceException(Constants.FAILURE, "Invoice Number is not unique , Please send new invoice");
		}
		if (CommonUtil.isNotNull(singlePaymentInvoice.getSingleInvoicePaymentRequest().getInvoiceNumber())
				&& singlePaymentInvoice.getSingleInvoicePaymentRequest().getInvoiceNumber().length() > 16) {
			throw new InvoiceException(Constants.FAILURE, "Invoice Number cannot be more than 16 characters");
		}
		String invoiceCode = singlePaymentInvoice.getSingleInvoicePaymentRequest().getInvoiceNumber();
		if (invoiceCode == null || "".equals(invoiceCode)) {
			invoiceCode = String.valueOf(new Date().getTime());
			invoiceCode = RandomIdGenerator
					.generateInvoiceCode((invoiceCode + invoiceCode.toUpperCase()).toCharArray());
		}
		singlePaymentInvoice.getSingleInvoicePaymentRequest().setInvoiceNumber(invoiceCode);
	}

	public void SendInvoiceLinks(String shortenedPaymentLink, Boolean viaSms, Boolean viaEmail) {
		getInvoiceModel.getInvoiceModelByInvoiceLink(shortenedPaymentLink);
	}

}