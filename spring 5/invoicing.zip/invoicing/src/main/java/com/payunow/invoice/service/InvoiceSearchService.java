package com.payunow.invoice.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payunow.invoice.db.dao.IGetInvoiceModel;
import com.payunow.invoice.dto.InvoiceSearchResponseDTO;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.model.InvoiceModel;
import com.payunow.invoice.request.payload.InvoiceSearchRequest;
import com.payunow.invoice.type.InvoiceLinkStatus;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;
import com.payunow.invoice.util.DateUtil;

import reactor.core.publisher.Flux;

/**
 * Reactive implementation of searching invoices service.
 * 
 * @author nishant
 *
 */
@Service
public class InvoiceSearchService {

	@Autowired
	private IGetInvoiceModel getInvoiceModel;

	private final static Logger LOGGER = LoggerFactory.getLogger(InvoiceSearchService.class);

	/**
	 * Returns stream of invoices based on search criteria.
	 * 
	 * @param invoiceSearchRequest
	 * 
	 * @return Flux<InvoiceSearchResponseDTO>
	 */
	public Flux<InvoiceSearchResponseDTO> searchInvoices(InvoiceSearchRequest invoiceSearchRequest) {
		invoiceSearchRequest = (InvoiceSearchRequest) CommonUtil.trimRootLevelStringFields(invoiceSearchRequest);
		LOGGER.info("Invoice search request : {}", invoiceSearchRequest);
		validateSearchRequest(invoiceSearchRequest);
		Map<String, Object> params = prepareParams(invoiceSearchRequest);
		Flux<InvoiceModel> invoicesStream = getInvoiceModel.getInvoiceDocsByMultipleParameters(params,
				CommonUtil.isNull(invoiceSearchRequest.getFrom()) ? null
						: DateUtil.convertToIST(invoiceSearchRequest.getFrom()),
				CommonUtil.isNull(invoiceSearchRequest.getTo()) ? null
						: DateUtil.convertToIST(invoiceSearchRequest.getTo()));
		return invoicesStream.map(invoiceData -> new InvoiceSearchResponseDTO(invoiceData.getAddedOn(),
				invoiceData.getInvoiceNumber(), invoiceData.getInvoiceDescription(), invoiceData.getTotalAmount(),
				invoiceData.getInvoiceStatus()));
	}

	private Map<String, Object> prepareParams(InvoiceSearchRequest request) {
		Map<String, Object> param = new HashMap<>();
		param.put("merchantId", request.getMerchantId());
		param.put("invoiceNumber", request.getInvoiceCode());
		param.put("invoiceDescription", request.getInvoiceDescription());
		param.put("invoiceStatus", request.getStatus());
		param.put("totalAmount", request.getAmount());
		return param;
	}

	private void validateSearchRequest(InvoiceSearchRequest request) {
		if (CommonUtil.isEmpty(request.getMerchantId())) {
			LOGGER.info("Merchant Id is mandatory");
			throw new InvoiceException(Constants.FAILURE, "Invalid Merchant");

		}
		if (CommonUtil.isNotNull(request.getStatus())) {
			try {
				InvoiceLinkStatus.valueOf(request.getStatus());
			} catch (Exception e) {
				LOGGER.info("Invalid Invoice Status :", request.getStatus());
				throw new InvoiceException(Constants.FAILURE, "Invalid Invoice Status :" + request.getStatus());
			}
		}
		if (CommonUtil.isNotNull(request.getAmount())) {
			if (CommonUtil.isNull(CommonUtil.safeParseDouble(request.getAmount()))) {
				LOGGER.info("Invalid Amount :", request.getAmount());
				throw new InvoiceException(Constants.FAILURE, "Invalid Amount");
			}
		}
	}
}