package com.payunow.invoice.model;

import org.bson.Document;

public class PaymentDetails {

	private String paymentStatus;

	private String paymentUrl;

	public PaymentDetails(String paymentStatus, String paymentUrl) {
		super();
		this.paymentStatus = paymentStatus;
		this.paymentUrl = paymentUrl;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public static PaymentDetails getPaymentDetails(Document document) {
		try {
			PaymentDetails paymentDetail = new PaymentDetails(document.getString("paymentStatus"),
					document.getString("paymentUrl"));
			return paymentDetail;
		} catch (Exception ex) {
			return null;
		}
	}

	public String getPaymentUrl() {
		return paymentUrl;
	}

	public void setPaymentUrl(String paymentUrl) {
		this.paymentUrl = paymentUrl;
	}

	@Override
	public String toString() {
		return "PaymentDetails [paymentStatus=" + paymentStatus + ", paymentUrl=" + paymentUrl + "]";
	}

}
