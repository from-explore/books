package com.payunow.invoice.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.payunow.invoice.db.dao.IGetInvoiceModel;
import com.payunow.invoice.db.dao.IUpdateInvoiceModel;
import com.payunow.invoice.dto.InvoiceTxnFinalResponseDTO;
import com.payunow.invoice.model.InvoiceModel;
import com.payunow.invoice.model.PaymentDetails;
import com.payunow.invoice.util.CommonUtil;

import reactor.core.publisher.Mono;

@Service
public class NotifyService {

	@Autowired
	IGetInvoiceModel getInvoiceModel;

	@Autowired
	IUpdateInvoiceModel updateInvoiceModel;

	private final static Logger LOGGER = LoggerFactory.getLogger(NotifyService.class);

	public void updateInvoiceTransactionSuccesfulCount(InvoiceTxnFinalResponseDTO successResponseFromPayuMoney) {
		String invoiceNumber = successResponseFromPayuMoney.getInvoiceNumber();
		String merchantId = successResponseFromPayuMoney.getMerchantId();
		String paymentId = successResponseFromPayuMoney.getPaymentId();
		LOGGER.info("Inside Notify Controller for Invoice Number : {} merchantId : {}", invoiceNumber, merchantId);
		Mono<InvoiceModel> model = getInvoiceModel.getInvoiceModelByInvoiceNumberAndMerchantId(invoiceNumber,
				merchantId);
		if (CommonUtil.isNull(model)) {
			LOGGER.info("Notify API failed as Invoice not present in DB for InvoiceNumber {} PaymentId {}",
					invoiceNumber, paymentId);
		}
		model.doOnSuccess(invoice -> {
			Integer count = invoice.getSuccesfulPaymentsCount();
			HashMap<String, PaymentDetails> paymentDetailsMap = invoice.getPaymentDetails();
			Gson gson = new Gson();
			PaymentDetails paymentDetails = paymentDetailsMap.get(paymentId);
			paymentDetails.setPaymentStatus("Success");
			paymentDetailsMap.put(paymentId, paymentDetails);
			Map<String, Object> updateMap = new HashMap<String, Object>();
			updateMap.put("paymentDetails", gson.toJson(paymentDetailsMap));
			updateMap.put("succesfulPaymentsCount", ++count);
			LOGGER.info("Updating DB success count for Invoice Number : {} merchantId : {}", invoiceNumber, merchantId);
			updateInvoiceModel.update(invoice, updateMap);
		});
		model.doOnError(error -> {
			LOGGER.info("Error updating success count for Invoice Number : {}}", invoiceNumber, error);
		});
	}

}