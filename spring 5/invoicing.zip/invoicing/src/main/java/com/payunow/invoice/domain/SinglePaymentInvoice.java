package com.payunow.invoice.domain;

import com.payunow.invoice.dto.MerchantDTO;
import com.payunow.invoice.request.payload.SingleInvoicePaymentRequest;

public class SinglePaymentInvoice {

	private SingleInvoicePaymentRequest singleInvoicePaymentRequest;

	private MerchantDTO merchant;

	public SingleInvoicePaymentRequest getSingleInvoicePaymentRequest() {
		return singleInvoicePaymentRequest;
	}

	public void setSingleInvoicePaymentRequest(SingleInvoicePaymentRequest singleInvoicePaymentRequest) {
		this.singleInvoicePaymentRequest = singleInvoicePaymentRequest;
	}

	public MerchantDTO getMerchant() {
		return merchant;
	}

	public void setMerchant(MerchantDTO merchant) {
		this.merchant = merchant;
	}

}