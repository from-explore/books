package com.payunow.invoice.db.dao;

import java.util.Map;

import org.bson.Document;
import org.springframework.stereotype.Service;

import com.payunow.invoice.model.InvoiceModel;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Reactive implementation of fetching invoices service.
 * 
 * @author nishant
 *
 */
@Service
public interface IGetInvoiceModel {

	/**
	 * Fetches invoices by invoice number.
	 * 
	 * @param invoiceNumber
	 * 
	 * @return Mono<InvoiceModel>
	 */
	public Mono<InvoiceModel> getInvoiceModelByInvoiceNumber(String invoice_number);

	/**
	 * Fetches invoices by given parameters within a date range.
	 * 
	 * @param param
	 * @param fromDate
	 * @param toDate
	 * 
	 * @return Flux<InvoiceModel>
	 */
	public Flux<InvoiceModel> getInvoiceDocsByMultipleParameters(Map<String, Object> param, String fromDate,
			String toDate);

	/**
	 * Converts a document to invoice model.
	 * 
	 * @param document
	 * @return InvoiceModel
	 */
	public InvoiceModel getModel(Document document);

	/**
	 * Fetches invoices by invoice number and merchant Id.
	 * 
	 * @param invoiceNumber
	 * @param merchantId
	 * 
	 * @return Mono<InvoiceModel>
	 */
	public Mono<InvoiceModel> getInvoiceModelByInvoiceNumberAndMerchantId(String invoice_number, String merchantId);

	/**
	 * Fetches invoice by link.
	 * 
	 * @param link
	 * 
	 * @return Mono<InvoiceModel>
	 */
	public Mono<InvoiceModel> getInvoiceModelByInvoiceLink(String link);

}