package com.payunow.invoice.dto;


import java.util.Map;
import java.util.Set;

public class ClientDetails {

    String clientId;
    String clientSecret;
    Set<String> scopes;
    Set<String> grantTypes;
    Map<String, Object> additionalInformation;

    public ClientDetails() {

    }

    public ClientDetails(String clientId, String clientSecret,
                            Set<String> scopes, Set<String> grantTypes,
                            Map<String, Object> additionalInformation) {
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.scopes = scopes;
        this.grantTypes = grantTypes;
        this.additionalInformation = additionalInformation;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public Set<String> getScope() {
        return scopes;
    }

    public void setScope(Set<String> scopes) {
        this.scopes = scopes;
    }

    public Set<String> getAuthorizedGrantTypes() {
        return grantTypes;
    }

    public void setAuthorizedGrantTypes(Set<String> grantTypes) {
        this.grantTypes = grantTypes;
    }

    public Map<String, Object> getAdditionalInformation() {
        return additionalInformation;
    }

    public void setAdditionalInformation(
            Map<String, Object> additionalInformation) {
        this.additionalInformation = additionalInformation;
    }

}
