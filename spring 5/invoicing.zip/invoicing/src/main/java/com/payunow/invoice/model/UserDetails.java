package com.payunow.invoice.model;

import java.io.Serializable;

import org.bson.Document;

public class UserDetails implements Serializable {

	/**
	 * @author manan.khandelwal
	 */

	private static final long serialVersionUID = 1L;

	private String name;

	private String email;

	private String phoneNumber;

	private String alternateNumber;

	private Address address;

	public UserDetails(String name, String email, String phoneNumber, String alternateNumber, Address address) {
		super();
		this.name = name;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.alternateNumber = alternateNumber;
		this.address = address;
	}

	public UserDetails() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone_number() {
		return phoneNumber;
	}

	public void setPhone_number(String phone_number) {
		this.phoneNumber = phone_number;
	}

	public String getAlternate_number() {
		return alternateNumber;
	}

	public void setAlternate_number(String alternate_number) {
		this.alternateNumber = alternate_number;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public static UserDetails getUserDetails(Document document) {
		try {
			UserDetails userDetails = new UserDetails(document.getString("name"), document.getString("email"),
					document.getString("phoneNumber"), document.getString("alternateNumber"),
					Address.getAddress(document.get("address", Document.class)));
			return userDetails;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public String toString() {
		return "UserDetails [name=" + name + ", email=" + email + ", phoneNumber=" + phoneNumber + ", alternateNumber="
				+ alternateNumber + ", address=" + address + "]";
	}

}
