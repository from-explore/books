package com.payunow.invoice.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.google.gson.JsonObject;
import com.payunow.invoice.exception.InvoiceException;

import reactor.core.publisher.Mono;

@Component
public class PayuMoneyUrlShortener {

	@Value("${tiny.payu.url}")
	private String payuShorternUrl;

	private final static Logger LOGGER = LoggerFactory.getLogger(PayuMoneyUrlShortener.class);

	public Mono<String> shortenUrl(final String paymentUrl) {
		try {
			LOGGER.info("Shortening payment url with original url {}", paymentUrl);
			WebClient client = WebClient.create();
			JsonObject reqBody = new JsonObject();
			reqBody.addProperty("url", paymentUrl);
			reqBody.addProperty("allowAllDomain", true);
			return client.post().uri(payuShorternUrl).contentType(MediaType.APPLICATION_JSON_UTF8).syncBody(reqBody)
					.exchange().flatMap(response -> response.bodyToMono(String.class));
		} catch (Exception e) {
			LOGGER.error("Error while shortening payment url with original url {}", paymentUrl, e);
			throw new InvoiceException(Constants.FAILURE, "Shortening payment url failed.");
		}
	}

}