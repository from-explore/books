package com.payunow.invoice.validate;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;

@Component
@Order(5)
public class IsValidInvoiceDescription implements RequestValidator<SinglePaymentInvoice> {

	@Override
	public void validate(SinglePaymentInvoice t) {

		if (CommonUtil.isEmpty(t.getSingleInvoicePaymentRequest().getInvoiceDescription())
				|| t.getSingleInvoicePaymentRequest().getInvoiceDescription().length() > 40) {
			throw new InvoiceException(Constants.FAILURE, "Invoice Desc is missing or length is greater than 40 characters");
		}

	}

}
