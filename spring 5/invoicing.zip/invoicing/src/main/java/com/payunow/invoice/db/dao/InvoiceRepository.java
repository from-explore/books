package com.payunow.invoice.db.dao;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.payunow.invoice.model.InvoiceModel;
import com.payunow.invoice.util.CommonUtil;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class InvoiceRepository {

	@Autowired
	ReactiveMongoTemplate template;

	/**
	 * Fetches invoice by invoice number and merchant Id.
	 * 
	 * @param invoiceNumber
	 * @param merchantId
	 * 
	 * @return Mono<InvoiceModel>
	 */
	public Mono<InvoiceModel> getInvoiceModelByInvoiceNumberAndMerchantId(String invoiceNumber, String merchantId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("invoiceNumber").is(invoiceNumber).and("merchantId").is(merchantId));
		return template.findOne(query, InvoiceModel.class);
	}

	/**
	 * Fetches invoice by invoice number.
	 * 
	 * @param invoiceNumber
	 * 
	 * @return Mono<InvoiceModel>
	 */
	public Mono<InvoiceModel> getInvoiceModelByInvoiceNumber(String invoiceNumber) {
		Query query = new Query();
		query.addCriteria(Criteria.where("invoiceNumber").is(invoiceNumber));
		return template.findOne(query, InvoiceModel.class);
	}

	/**
	 * Fetches invoices by given parameters within a date range.
	 * 
	 * @param param
	 * @param fromDate
	 * @param toDate
	 * 
	 * @return Flux<InvoiceModel>
	 */
	public Flux<InvoiceModel> getInvoiceDocsByMultipleParameters(Map<String, Object> param, String fromDate,
			String toDate) {
		Query query = new Query();
		Criteria criteria = Criteria.where("addedOn").exists(true).andOperator(Criteria.where("addedOn").gt(fromDate),
				Criteria.where("addedOn").lt(toDate));
		for (Map.Entry<String, Object> entry : param.entrySet()) {
			if (CommonUtil.isNotNull(entry.getValue()))
				criteria.andOperator(Criteria.where(entry.getKey()).is(entry.getValue()));
		}
		query.addCriteria(criteria);
		return template.find(query, InvoiceModel.class);
	}

	/**
	 * Create an invoice.
	 * 
	 * @param model
	 * 
	 * @return Mono<InvoiceModel>
	 */
	public Mono<InvoiceModel> create(InvoiceModel invoice) {
		return template.insert(invoice);
	}

	/**
	 * Update an invoice.
	 * 
	 * @param model
	 * 
	 * @return Mono<InvoiceModel>
	 */
	public Mono<InvoiceModel> save(InvoiceModel invoice) {
		return template.save(invoice);
	}

	/**
	 * Fetches invoice by link.
	 * 
	 * @param link
	 * 
	 * @return Mono<InvoiceModel>
	 */
	public Mono<InvoiceModel> getInvoiceModelByInvoiceLink(String link) {
		Query query = new Query();
		query.addCriteria(Criteria.where("shortenedUrl").is(link));
		return template.findOne(query, InvoiceModel.class);
	}
}