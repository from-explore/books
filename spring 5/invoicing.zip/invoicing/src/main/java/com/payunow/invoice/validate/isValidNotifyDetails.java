package com.payunow.invoice.validate;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.model.NotifyThirdParty;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;

@Component
@Order(10)
public class isValidNotifyDetails implements RequestValidator<SinglePaymentInvoice> {

	@Override
	public void validate(SinglePaymentInvoice t) {
		if (CommonUtil.isNotEmpty(t.getSingleInvoicePaymentRequest().getNotify())) {
			for (NotifyThirdParty invThirdParty : t.getSingleInvoicePaymentRequest().getNotify()) {
				if (!invThirdParty.getNumber().matches(Constants.PHONE_PATTERN)) {
					throw new InvoiceException(Constants.FAILURE, "Invalid third party phone number");
				}
				if (!invThirdParty.getEmail().matches(Constants.EMAIL_PATTERN)) {
					throw new InvoiceException(Constants.FAILURE, "Invalid third party Email");
				}
				if (!invThirdParty.getName().matches(Constants.NAME_PATTERN)) {
					throw new InvoiceException(Constants.FAILURE, "Invalid third party name");
				}
			}
		}
	}
}
