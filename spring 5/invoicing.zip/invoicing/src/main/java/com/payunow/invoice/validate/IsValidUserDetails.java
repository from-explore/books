package com.payunow.invoice.validate;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.model.Address;
import com.payunow.invoice.model.UserDetails;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;

@Component
@Order(8)
public class IsValidUserDetails implements RequestValidator<SinglePaymentInvoice> {

	@Override
	public void validate(SinglePaymentInvoice t) {
		if (CommonUtil.isNotNull(t.getSingleInvoicePaymentRequest().getChannel())) {
			if (CommonUtil.isNotNull(t.getSingleInvoicePaymentRequest().getChannel().getViaEmail())
					&& t.getSingleInvoicePaymentRequest().getChannel().getViaEmail()) {
				if (CommonUtil.isNull(t.getSingleInvoicePaymentRequest().getUserDetails())
						|| CommonUtil.isEmpty(t.getSingleInvoicePaymentRequest().getUserDetails().getEmail())
						|| CommonUtil.isEmpty(t.getSingleInvoicePaymentRequest().getUserDetails().getName())) {
					throw new InvoiceException(Constants.FAILURE,
							"Consumer's email, first-name required to send invoice email");
				}
			}
			if (CommonUtil.isNotNull(t.getSingleInvoicePaymentRequest().getChannel().getViaSms())
					&& t.getSingleInvoicePaymentRequest().getChannel().getViaSms()) {
				if (CommonUtil.isNull(t.getSingleInvoicePaymentRequest().getUserDetails())
						|| CommonUtil.isEmpty(t.getSingleInvoicePaymentRequest().getUserDetails().getPhone_number())
						|| CommonUtil.isEmpty(t.getSingleInvoicePaymentRequest().getUserDetails().getName())) {
					throw new InvoiceException(Constants.FAILURE,
							"Consumer's mobile number, first-name required to send invoice sms");
				}
			}
		}
		if (!CommonUtil.isNull(t.getSingleInvoicePaymentRequest().getUserDetails())) {
			UserDetails userDetails = t.getSingleInvoicePaymentRequest().getUserDetails();
			if (CommonUtil.isNotNull(userDetails.getPhone_number())) {
				if (CommonUtil.isNotEmpty(userDetails.getEmail())
						&& !match(t.getSingleInvoicePaymentRequest().getUserDetails().getPhone_number(),
								Constants.PHONE_PATTERN)) {
					throw new InvoiceException(Constants.FAILURE, "Invalid phone number");
				}
			}
			if (CommonUtil.isNotEmpty(userDetails.getEmail())
					&& !match(userDetails.getEmail(), Constants.EMAIL_PATTERN)) {
				throw new InvoiceException(Constants.FAILURE, "Invalid Email");
			}
			if (CommonUtil.isNotEmpty(userDetails.getEmail())
					&& !match(userDetails.getName(), Constants.NAME_PATTERN)) {
				throw new InvoiceException(Constants.FAILURE, "Invalid First Name");
			}
			if (CommonUtil.isNotEmpty(userDetails.getEmail())
					&& !match(userDetails.getAlternate_number(), Constants.PHONE_PATTERN)) {
				throw new InvoiceException(Constants.FAILURE, "Invalid Alternate phone number");
			}
			if (CommonUtil.isNotNull(userDetails.getAddress())) {
				Address address = userDetails.getAddress();
				if (CommonUtil.isNotEmpty(userDetails.getEmail())
						&& !match(address.getAddressCity(), Constants.NAME_PATTERN)) {
					throw new InvoiceException(Constants.FAILURE, "Invalid City Name");
				}
				if (CommonUtil.isNotEmpty(userDetails.getEmail())
						&& !match(address.getAddressState(), Constants.NAME_PATTERN)) {
					throw new InvoiceException(Constants.FAILURE, "Invalid State Name");
				}
				if (CommonUtil.isNotEmpty(userDetails.getEmail())
						&& !match(address.getAddressCountry(), Constants.NAME_PATTERN)) {
					throw new InvoiceException(Constants.FAILURE, "Invalid Country Name");
				}
				if (CommonUtil.isNotEmpty(userDetails.getEmail())
						&& !match(address.getAddressZip(), Constants.ZIP_PATTERN)) {
					throw new InvoiceException(Constants.FAILURE, "Invalid Zip Code");
				}
			}
		}

	}

	private boolean match(String value, String pattern) {
		if (CommonUtil.isNotNull(value)) {
			return value.matches(pattern);
		}
		return true;
	}

}
