package com.payunow.invoice.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.mapping.Document;

import com.google.gson.annotations.SerializedName;

@Document
public class InvoiceModel implements Serializable {

	/**
	 * @author manan.khandelwal
	 */

	// private static final Logger LOGGER =
	// LoggerFactory.getLogger(InvoiceModel.class);

	private static final long serialVersionUID = 1L;

	@SerializedName("_id")
	private Long docId;

	private String invoiceNumber;
	private String merchantId;
	private String invoiceDescription;
	private String currency;
	private UserDetails userDetails;
	private Amount amount;
	private String totalAmount;
	private String shortenedUrl;
	private String addedOn;
	private String expiryDate;
	private String updatedOn;
	private String invoiceStatus;
	private Integer maxPaymentsAllowed;
	private Integer succesfulPaymentsCount;
	private CartAndShippingDetails cartAndShippingDetails;
	private Channel channel;
	private Map<String, String> customParams;
	private RecurringInvoiceDetail recurringInvoiceDetail;
	private List<NotifyThirdParty> notifyThirdPartyDetails;
	private String invoiceLinkstatus;
	private HashMap<String, PaymentDetails> paymentDetails;

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getInvoiceDescription() {
		return invoiceDescription;
	}

	public void setInvoiceDescription(String invoiceDescription) {
		this.invoiceDescription = invoiceDescription;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

	public Amount getAmount() {
		return amount;
	}

	public void setAmount(Amount amount) {
		this.amount = amount;
	}

	public String getShortenedUrl() {
		return shortenedUrl;
	}

	public void setShortenedUrl(String shortenedUrl) {
		this.shortenedUrl = shortenedUrl;
	}

	public String getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(String addedOn) {
		this.addedOn = addedOn;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(String updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getInvoiceStatus() {
		return invoiceStatus;
	}

	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}

	public Integer getMaxPaymentsAllowed() {
		return maxPaymentsAllowed;
	}

	public void setMaxPaymentsAllowed(Integer maxPaymentsAllowed) {
		this.maxPaymentsAllowed = maxPaymentsAllowed;
	}

	public Integer getSuccesfulPaymentsCount() {
		return succesfulPaymentsCount;
	}

	public void setSuccesfulPaymentsCount(Integer succesfulPaymentsCount) {
		this.succesfulPaymentsCount = succesfulPaymentsCount;
	}

	public Channel getChannel() {
		return channel;
	}

	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	public Map<String, String> getCustomParams() {
		return customParams;
	}

	public void setCustomParams(Map<String, String> customParams) {
		this.customParams = customParams;
	}

	public RecurringInvoiceDetail getRecurringInvoiceDetail() {
		return recurringInvoiceDetail;
	}

	public void setRecurringInvoiceDetail(RecurringInvoiceDetail recurringInvoiceDetail) {
		this.recurringInvoiceDetail = recurringInvoiceDetail;
	}

	public List<NotifyThirdParty> getNotifyThirdPartyDetails() {
		return notifyThirdPartyDetails;
	}

	public void setNotifyThirdPartyDetails(List<NotifyThirdParty> notifyThirdPartyDetails) {
		this.notifyThirdPartyDetails = notifyThirdPartyDetails;
	}

	public String getInvoiceLinkstatus() {
		return invoiceLinkstatus;
	}

	public void setInvoiceLinkstatus(String invoiceLinkstatus) {
		this.invoiceLinkstatus = invoiceLinkstatus;
	}

	public HashMap<String, PaymentDetails> getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(HashMap<String, PaymentDetails> paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public CartAndShippingDetails getCartAndShippingDetails() {
		return cartAndShippingDetails;
	}

	public void setCartAndShippingDetails(CartAndShippingDetails cartAndShippingDetails) {
		this.cartAndShippingDetails = cartAndShippingDetails;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

}