package com.payunow.invoice.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

public class Cart implements Serializable {

	/**
	 * @author manan.khandelwal
	 */

	private static final long serialVersionUID = 1L;

	private String itemId;
	private String itemDescription;
	private String unitPrice;
	private Integer quantity;
	private String itemAmount;
	private String height;
	private String weight;
	private String length;
	private String width;
	private List<Tax> tax;
	private Discount discount;

	public Cart(String itemId, String itemDescription, String unitPrice, Integer quantity, String itemAmount,
			String height, String weight, String length, String width, List<Tax> tax, Discount discount) {
		super();
		this.itemId = itemId;
		this.itemDescription = itemDescription;
		this.unitPrice = unitPrice;
		this.quantity = quantity;
		this.itemAmount = itemAmount;
		this.height = height;
		this.weight = weight;
		this.length = length;
		this.width = width;
		this.tax = tax;
		this.discount = discount;
	}

	public Cart() {
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getLength() {
		return length;
	}

	public void setLength(String length) {
		this.length = length;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String item_id) {
		this.itemId = item_id;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String item_description) {
		this.itemDescription = item_description;
	}

	public String getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(String unit_price) {
		this.unitPrice = unit_price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(String item_amount) {
		this.itemAmount = item_amount;
	}

	public List<Tax> getTax() {
		return tax;
	}

	public void setTax(List<Tax> tax) {
		this.tax = tax;
	}

	public Discount getDiscount() {
		return discount;
	}

	public void setDiscount(Discount discount) {
		this.discount = discount;
	}

	@SuppressWarnings("unchecked")
	public static List<Cart> getCartDetails(List<Document> list) {
		try {
			List<Cart> cartList = new ArrayList<Cart>();
			for (Document document : list) {
				Cart cart = new Cart(document.getString("itemId"), document.getString("itemDescription"),
						document.getString("unitPrice"), document.getInteger("quantity"),
						document.getString("itemAmount"), document.getString("height"), document.getString("weight"),
						document.getString("length"), document.getString("width"),
						Tax.getTaxList((List<Document>) document.get("tax")),
						Discount.getDiscountInfo(document.get("discount", Document.class)));
				cartList.add(cart);
			}
			return cartList;
		} catch (Exception ex) {
			return null;
		}
	}

	@Override
	public String toString() {
		return "Cart [itemId=" + itemId + ", itemDescription=" + itemDescription + ", unitPrice=" + unitPrice
				+ ", quantity=" + quantity + ", itemAmount=" + itemAmount + ", height=" + height + ", weight=" + weight
				+ ", length=" + length + ", width=" + width + ", tax=" + tax + ", discount=" + discount + "]";
	}

}
