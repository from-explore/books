package com.payunow.invoice.validate;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.payunow.invoice.domain.SinglePaymentInvoice;
import com.payunow.invoice.exception.InvoiceException;
import com.payunow.invoice.type.Currency;
import com.payunow.invoice.util.CommonUtil;
import com.payunow.invoice.util.Constants;
import com.payunow.invoice.validate.RequestValidator;

@Component
@Order(1)
public class isValidCurrency implements RequestValidator<SinglePaymentInvoice> {

	@Override
	public void validate(SinglePaymentInvoice t) {
		if (CommonUtil.isNotEmpty(t.getSingleInvoicePaymentRequest().getCurrency())) {
			try {
				Currency.valueOf(t.getSingleInvoicePaymentRequest().getCurrency());
			} catch (Exception ex) {
				throw new InvoiceException(Constants.FAILURE, "Invalid Currency");
			}
		}
	}

}
