package com.payunow.invoice.model;

import java.io.Serializable;

import org.bson.Document;

public class Shipping implements Serializable {

	/**
	 * @author manan.khandelwal
	 */

	private static final long serialVersionUID = 1L;

	private String shippingCharge;
	private Address shippingAddress;

	public Shipping(String shippingCharge, Address shippingAddress) {
		super();
		this.shippingCharge = shippingCharge;
		this.setShippingAddress(shippingAddress);
	}

	public Shipping() {
	}

	public String getShippingCharge() {
		return shippingCharge;
	}

	public void setShippingCharge(String shippingCharge) {
		this.shippingCharge = shippingCharge;
	}

	public static Shipping getShippingInfo(Document document) {
		try {
			Shipping shipping = new Shipping(document.getDouble("shippingCharge").toString(),
					Address.getAddress(document.get("shippingAddress", Document.class)));
			return shipping;
		} catch (Exception ex) {
			return null;
		}
	}

	public Address getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(Address shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

}
