package com.payunow.invoice.dto;

import java.util.HashMap;

public class SmsNotificationDTO {

	private String templateName;

	private String phone;

	private String text;

	private String description;

	private String type;

	private String application;

	private HashMap<String, String> params;

	private String immediate;

	public SmsNotificationDTO(String templateName, String phone, String text, String description, String type,
			String application, HashMap<String, String> params, String immediate) {
		super();
		this.templateName = templateName;
		this.phone = phone;
		this.text = text;
		this.description = description;
		this.type = type;
		this.application = application;
		this.params = params;
		this.immediate = immediate;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public HashMap<String, String> getParams() {
		return params;
	}

	public void setParams(HashMap<String, String> params) {
		this.params = params;
	}

	public String getImmediate() {
		return immediate;
	}

	public void setImmediate(String immediate) {
		this.immediate = immediate;
	}

}
