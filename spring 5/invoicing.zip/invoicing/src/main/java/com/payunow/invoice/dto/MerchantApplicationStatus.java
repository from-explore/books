package com.payunow.invoice.dto;

import java.util.Date;

import com.payunow.invoice.util.Constants;

public class MerchantApplicationStatus {

	private Integer merchantApplicationStatusId;

	private Integer merchantId;

	private Integer nodalStatus = Constants.NodalStatus.NOTSTARTED.v;

	private Date nodalStatusUpdatedOn;

	private Integer agreementStatus;

	private Integer paymentOptionStatus;

	private Date paymentOptionStatusUpdatedOn;

	private Integer websiteCheckStatus;

	private Date websiteCheckStatusUpdatedOn;

	private Integer bankDetailsStatus;

	private Date bankDetailsStatusUpdatedOn;

	private Boolean isAutoApproved = Boolean.FALSE;

	private Integer businessDetailsStatus;

	private Date businessDetailsStatusUpdatedOn;

	private Integer merchantApplicationApprovalStatus;

	private Date merchantApplicationApprovalUpdatedOn;

	private Integer contactDetailsStatus;

	private Date contactDetailsStatusUpdatedOn;

	private Integer businessEmailVerificationStatus;

	private Integer businessPhoneVerificationStatus;

	public BankAccountStatus bankAccountStatus;

	private Integer appStatus = 0;

	private Date appStatusUpdatedOn = new Date();

	private Integer businessLineStatus = 0;

	private Date businessLineStatusUpdatedOn = new Date();

	private Integer updatedBy = 0;

	private Integer merchantOnBoardingStatus = 4;

	private Integer previousMerchantApplicationApprovalStatus = 0;

	private Integer merchantRiskStatus;

	private Integer keySaltNotificationEmail = 0;

	private Integer qualityScore;

	// TODO: have separate updated on for all the statuses and have separate
	// updated on for pp approval, website approval, etc
	public Integer getMerchantApplicationStatusId() {
		return merchantApplicationStatusId;
	}

	public void setMerchantApplicationStatusId(Integer merchantApplicationStatusId) {
		this.merchantApplicationStatusId = merchantApplicationStatusId;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public Integer getNodalStatus() {
		return nodalStatus;
	}

	public void setNodalStatus(Integer nodalStatus) {
		this.nodalStatus = nodalStatus;
		this.nodalStatusUpdatedOn = new Date();
	}

	public Integer getAgreementStatus() {
		return agreementStatus;
	}

	public void setAgreementStatus(Integer agreementStatus) {
		this.agreementStatus = agreementStatus;
	}

	public Integer getPaymentOptionStatus() {
		return paymentOptionStatus;
	}

	public void setPaymentOptionStatus(Integer paymentOptionStatus) {
		this.paymentOptionStatus = paymentOptionStatus;
		this.paymentOptionStatusUpdatedOn = new Date();
	}

	public Integer getWebsiteCheckStatus() {
		return websiteCheckStatus;
	}

	public void setWebsiteCheckStatus(Integer websiteCheckStatus) {
		this.websiteCheckStatus = websiteCheckStatus;
		this.websiteCheckStatusUpdatedOn = new Date();
	}

	public Integer getBusinessDetailsStatus() {
		return businessDetailsStatus;
	}

	public void setBusinessDetailsStatus(Integer businessDetailsStatus) {
		this.businessDetailsStatus = businessDetailsStatus;
		if (this.businessDetailsStatus == Constants.BusinessDetailsStatus.APPROVED.v) {
			this.isAutoApproved = Boolean.TRUE;
		}
		this.businessDetailsStatusUpdatedOn = new Date();
	}

	public Integer getMerchantApplicationApprovalStatus() {
		return merchantApplicationApprovalStatus;
	}

	public void setMerchantApplicationApprovalStatus(Integer merchantApplicationApprovalStatus) {
		if (merchantApplicationApprovalStatus == Constants.MerchantApprovalStatus.HDFC_ICICI_PG_APPROVED.v) {
			this.previousMerchantApplicationApprovalStatus = this.merchantApplicationApprovalStatus;
		}
		this.merchantApplicationApprovalStatus = merchantApplicationApprovalStatus;
		this.merchantApplicationApprovalUpdatedOn = new Date();

	}

	public Integer getContactDetailsStatus() {
		return contactDetailsStatus;
	}

	public void setContactDetailsStatus(Integer contactDetailsStatus) {
		this.contactDetailsStatus = contactDetailsStatus;
		this.contactDetailsStatusUpdatedOn = new Date();
	}

	public Integer getBusinessEmailVerificationStatus() {
		return businessEmailVerificationStatus;
	}

	public void setBusinessEmailVerificationStatus(Integer businessEmailVerificationStatus) {
		this.businessEmailVerificationStatus = businessEmailVerificationStatus;
	}

	public Integer getBusinessPhoneVerificationStatus() {
		return businessPhoneVerificationStatus;
	}

	public void setBusinessPhoneVerificationStatus(Integer businessPhoneVerificationStatus) {
		this.businessPhoneVerificationStatus = businessPhoneVerificationStatus;
	}

	public Integer getBankDetailsStatus() {
		return bankDetailsStatus;
	}

	public void setBankDetailsStatus(Integer bankDetailsStatus) {
		this.bankDetailsStatus = bankDetailsStatus;
		this.bankDetailsStatusUpdatedOn = new Date();
	}

	public Date getMerchantApplicationApprovalUpdatedOn() {
		return merchantApplicationApprovalUpdatedOn;
	}

	public Date getNodalStatusUpdatedOn() {
		return nodalStatusUpdatedOn;
	}

	public Date getPaymentOptionStatusUpdatedOn() {
		return paymentOptionStatusUpdatedOn;
	}

	public Date getWebsiteCheckStatusUpdatedOn() {
		return websiteCheckStatusUpdatedOn;
	}

	public Date getBankDetailsStatusUpdatedOn() {
		return bankDetailsStatusUpdatedOn;
	}

	public Date getBusinessDetailsStatusUpdatedOn() {
		return businessDetailsStatusUpdatedOn;
	}

	public Date getContactDetailsStatusUpdatedOn() {
		return contactDetailsStatusUpdatedOn;
	}

	public BankAccountStatus getBankAccountStatus() {
		return bankAccountStatus;
	}

	public Integer getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		MerchantApplicationStatus newMerchantApplicationStatus = (MerchantApplicationStatus) super.clone();
		return newMerchantApplicationStatus;
	}

	public Integer getAppStatus() {
		return appStatus;
	}

	public void setAppStatus(Integer appStatus) {
		this.appStatus = appStatus;
	}

	public Date getAppStatusUpdatedOn() {
		return appStatusUpdatedOn;
	}

	public void setAppStatusUpdatedOn(Date appStatusUpdatedOn) {
		this.appStatusUpdatedOn = appStatusUpdatedOn;
	}

	public Integer getBusinessLineStatus() {
		return businessLineStatus;
	}

	public void setBusinessLineStatus(Integer businessLineStatus) {
		this.businessLineStatus = businessLineStatus;
	}

	public Date getBusinessLineStatusUpdatedOn() {
		return businessLineStatusUpdatedOn;
	}

	public void setBusinessLineStatusUpdatedOn(Date businessLineStatusUpdatedOn) {
		this.businessLineStatusUpdatedOn = businessLineStatusUpdatedOn;
	}

	public Integer getMerchantOnBoardingStatus() {
		return merchantOnBoardingStatus;
	}

	public void setMerchantOnBoardingStatus(Integer merchantOnBoardingStatus) {
		this.merchantOnBoardingStatus = merchantOnBoardingStatus;
	}

	public Boolean getIsAutoApproved() {
		return isAutoApproved;
	}

	public void setIsAutoApproved(Boolean isAutoApproved) {
		this.isAutoApproved = isAutoApproved;
	}

	public Integer getPreviousMerchantApplicationApprovalStatus() {
		return previousMerchantApplicationApprovalStatus;
	}

	public void setPreviousMerchantApplicationApprovalStatus(Integer previousMerchantApplicationApprovalStatus) {
		this.previousMerchantApplicationApprovalStatus = previousMerchantApplicationApprovalStatus;
	}

	public Integer getMerchantRiskStatus() {
		return merchantRiskStatus;
	}

	public void setMerchantRiskStatus(Integer merchantRiskStatus) {
		this.merchantRiskStatus = merchantRiskStatus;
	}

	public Integer getKeySaltNotificationEmail() {
		return keySaltNotificationEmail;
	}

	public void setKeySaltNotificationEmail(Integer keySaltNotificationEmail) {
		this.keySaltNotificationEmail = keySaltNotificationEmail;
	}

	public Integer getQualityScore() {
		return qualityScore;
	}

	public void setQualityScore(Integer qualityScore) {
		this.qualityScore = qualityScore;
	}
}
